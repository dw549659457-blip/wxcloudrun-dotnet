"use strict";

// apps/miniprogram/src/components/summary-panel/index.ts
Component({
  properties: { rows: { type: Array, value: [] }, title: { type: String, value: "\u786E\u8BA4\u672C\u6B21\u8BB0\u5F55" } }
});
