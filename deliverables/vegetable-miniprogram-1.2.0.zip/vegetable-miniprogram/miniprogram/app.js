"use strict";

// apps/miniprogram/src/app.ts
var import_settings = require("./config/runtime.js");
App({
  globalData: { session: null, bindingToken: "", configurationError: "" },
  onLaunch() {
    const saved = wx.getStorageSync("warehouse:session");
    if (typeof saved === "object" && saved !== null && "token" in saved && typeof saved.token === "string" && "userId" in saved) {
      this.globalData.session = saved;
    }
    if (import_settings.settings.mode === "cloud") {
      if (import_settings.settings.envId) {
        wx.cloud.init({ env: import_settings.settings.envId, traceUser: false });
      } else {
        this.globalData.configurationError = "\u8BF7\u7BA1\u7406\u5458\u5148\u586B\u5199\u4E91\u6258\u7BA1\u73AF\u5883\u914D\u7F6E\uFF0C\u518D\u91CD\u65B0\u6253\u5F00\u5C0F\u7A0B\u5E8F";
      }
    }
  }
});
