// 只改 envId（云托管环境 ID）与 administratorPhone（可选）。
// 不填写数据库密码或 AppSecret；修改后在开发者工具点“编译”，不需要构建 npm。
module.exports = {
  settings: {
  "mode": "cloud",
  "envId": "prod-d7glkv54o7189eae7",
  "serviceName": "dotnet-4jwm",
  "apiBaseUrl": "http://127.0.0.1:8080",
  "administratorPhone": "",
  "developmentLogin": false,
  "businessUtcOffsetMinutes": 480
}
};
