"use strict";

// packages/contracts/src/constants.ts
var roleLabels = {
  ADMIN: "\u7BA1\u7406\u5458",
  ACCOUNTANT: "\u4F1A\u8BA1",
  DRIVER: "\u53F8\u673A",
  WORKER: "\u88C5\u83DC\u4EBA\u5458",
  OUTBOUND: "\u51FA\u5E93\u5458"
};
var resourceKinds = {
  dispatches: "DISPATCH",
  "work-records": "WORK",
  recoveries: "RECOVERY",
  outbounds: "OUTBOUND",
  "stock-documents": "STOCK"
};
function queryString(query) {
  const entries = Object.entries(query).filter(
    (entry) => entry[1] !== void 0 && entry[1] !== ""
  );
  return entries.map(([key2, value]) => `${encodeURIComponent(key2)}=${encodeURIComponent(String(value))}`).join("&");
}
function businessDateNow(offsetMinutes = 480) {
  return new Date(Date.now() + offsetMinutes * 6e4).toISOString().slice(0, 10);
}

// node_modules/.pnpm/decimal.js@10.6.0/node_modules/decimal.js/decimal.mjs
var EXP_LIMIT = 9e15;
var MAX_DIGITS = 1e9;
var NUMERALS = "0123456789abcdef";
var LN10 = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058";
var PI = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789";
var DEFAULTS = {
  // These values must be integers within the stated ranges (inclusive).
  // Most of these values can be changed at run-time using the `Decimal.config` method.
  // The maximum number of significant digits of the result of a calculation or base conversion.
  // E.g. `Decimal.config({ precision: 20 });`
  precision: 20,
  // 1 to MAX_DIGITS
  // The rounding mode used when rounding to `precision`.
  //
  // ROUND_UP         0 Away from zero.
  // ROUND_DOWN       1 Towards zero.
  // ROUND_CEIL       2 Towards +Infinity.
  // ROUND_FLOOR      3 Towards -Infinity.
  // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
  // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
  // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
  // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
  // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
  //
  // E.g.
  // `Decimal.rounding = 4;`
  // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
  rounding: 4,
  // 0 to 8
  // The modulo mode used when calculating the modulus: a mod n.
  // The quotient (q = a / n) is calculated according to the corresponding rounding mode.
  // The remainder (r) is calculated as: r = a - n * q.
  //
  // UP         0 The remainder is positive if the dividend is negative, else is negative.
  // DOWN       1 The remainder has the same sign as the dividend (JavaScript %).
  // FLOOR      3 The remainder has the same sign as the divisor (Python %).
  // HALF_EVEN  6 The IEEE 754 remainder function.
  // EUCLID     9 Euclidian division. q = sign(n) * floor(a / abs(n)). Always positive.
  //
  // Truncated division (1), floored division (3), the IEEE 754 remainder (6), and Euclidian
  // division (9) are commonly used for the modulus operation. The other rounding modes can also
  // be used, but they may not give useful results.
  modulo: 1,
  // 0 to 9
  // The exponent value at and beneath which `toString` returns exponential notation.
  // JavaScript numbers: -7
  toExpNeg: -7,
  // 0 to -EXP_LIMIT
  // The exponent value at and above which `toString` returns exponential notation.
  // JavaScript numbers: 21
  toExpPos: 21,
  // 0 to EXP_LIMIT
  // The minimum exponent value, beneath which underflow to zero occurs.
  // JavaScript numbers: -324  (5e-324)
  minE: -EXP_LIMIT,
  // -1 to -EXP_LIMIT
  // The maximum exponent value, above which overflow to Infinity occurs.
  // JavaScript numbers: 308  (1.7976931348623157e+308)
  maxE: EXP_LIMIT,
  // 1 to EXP_LIMIT
  // Whether to use cryptographically-secure random number generation, if available.
  crypto: false
  // true/false
};
var inexact;
var quadrant;
var external = true;
var decimalError = "[DecimalError] ";
var invalidArgument = decimalError + "Invalid argument: ";
var precisionLimitExceeded = decimalError + "Precision limit exceeded";
var cryptoUnavailable = decimalError + "crypto unavailable";
var tag = "[object Decimal]";
var mathfloor = Math.floor;
var mathpow = Math.pow;
var isBinary = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i;
var isHex = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i;
var isOctal = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i;
var isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
var BASE = 1e7;
var LOG_BASE = 7;
var MAX_SAFE_INTEGER = 9007199254740991;
var LN10_PRECISION = LN10.length - 1;
var PI_PRECISION = PI.length - 1;
var P = { toStringTag: tag };
P.absoluteValue = P.abs = function() {
  var x = new this.constructor(this);
  if (x.s < 0) x.s = 1;
  return finalise(x);
};
P.ceil = function() {
  return finalise(new this.constructor(this), this.e + 1, 2);
};
P.clampedTo = P.clamp = function(min2, max2) {
  var k, x = this, Ctor = x.constructor;
  min2 = new Ctor(min2);
  max2 = new Ctor(max2);
  if (!min2.s || !max2.s) return new Ctor(NaN);
  if (min2.gt(max2)) throw Error(invalidArgument + max2);
  k = x.cmp(min2);
  return k < 0 ? min2 : x.cmp(max2) > 0 ? max2 : new Ctor(x);
};
P.comparedTo = P.cmp = function(y) {
  var i, j, xdL, ydL, x = this, xd = x.d, yd = (y = new x.constructor(y)).d, xs = x.s, ys = y.s;
  if (!xd || !yd) {
    return !xs || !ys ? NaN : xs !== ys ? xs : xd === yd ? 0 : !xd ^ xs < 0 ? 1 : -1;
  }
  if (!xd[0] || !yd[0]) return xd[0] ? xs : yd[0] ? -ys : 0;
  if (xs !== ys) return xs;
  if (x.e !== y.e) return x.e > y.e ^ xs < 0 ? 1 : -1;
  xdL = xd.length;
  ydL = yd.length;
  for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) {
    if (xd[i] !== yd[i]) return xd[i] > yd[i] ^ xs < 0 ? 1 : -1;
  }
  return xdL === ydL ? 0 : xdL > ydL ^ xs < 0 ? 1 : -1;
};
P.cosine = P.cos = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.d) return new Ctor(NaN);
  if (!x.d[0]) return new Ctor(1);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
  Ctor.rounding = 1;
  x = cosine(Ctor, toLessThanHalfPi(Ctor, x));
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant == 2 || quadrant == 3 ? x.neg() : x, pr, rm, true);
};
P.cubeRoot = P.cbrt = function() {
  var e, m, n, r, rep, s, sd, t, t3, t3plusx, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  external = false;
  s = x.s * mathpow(x.s * x, 1 / 3);
  if (!s || Math.abs(s) == 1 / 0) {
    n = digitsToString(x.d);
    e = x.e;
    if (s = (e - n.length + 1) % 3) n += s == 1 || s == -2 ? "0" : "00";
    s = mathpow(n, 1 / 3);
    e = mathfloor((e + 1) / 3) - (e % 3 == (e < 0 ? -1 : 2));
    if (s == 1 / 0) {
      n = "5e" + e;
    } else {
      n = s.toExponential();
      n = n.slice(0, n.indexOf("e") + 1) + e;
    }
    r = new Ctor(n);
    r.s = x.s;
  } else {
    r = new Ctor(s.toString());
  }
  sd = (e = Ctor.precision) + 3;
  for (; ; ) {
    t = r;
    t3 = t.times(t).times(t);
    t3plusx = t3.plus(x);
    r = divide(t3plusx.plus(x).times(t), t3plusx.plus(t3), sd + 2, 1);
    if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
      n = n.slice(sd - 3, sd + 1);
      if (n == "9999" || !rep && n == "4999") {
        if (!rep) {
          finalise(t, e + 1, 0);
          if (t.times(t).times(t).eq(x)) {
            r = t;
            break;
          }
        }
        sd += 4;
        rep = 1;
      } else {
        if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
          finalise(r, e + 1, 1);
          m = !r.times(r).times(r).eq(x);
        }
        break;
      }
    }
  }
  external = true;
  return finalise(r, e, Ctor.rounding, m);
};
P.decimalPlaces = P.dp = function() {
  var w, d = this.d, n = NaN;
  if (d) {
    w = d.length - 1;
    n = (w - mathfloor(this.e / LOG_BASE)) * LOG_BASE;
    w = d[w];
    if (w) for (; w % 10 == 0; w /= 10) n--;
    if (n < 0) n = 0;
  }
  return n;
};
P.dividedBy = P.div = function(y) {
  return divide(this, new this.constructor(y));
};
P.dividedToIntegerBy = P.divToInt = function(y) {
  var x = this, Ctor = x.constructor;
  return finalise(divide(x, new Ctor(y), 0, 1, 1), Ctor.precision, Ctor.rounding);
};
P.equals = P.eq = function(y) {
  return this.cmp(y) === 0;
};
P.floor = function() {
  return finalise(new this.constructor(this), this.e + 1, 3);
};
P.greaterThan = P.gt = function(y) {
  return this.cmp(y) > 0;
};
P.greaterThanOrEqualTo = P.gte = function(y) {
  var k = this.cmp(y);
  return k == 1 || k === 0;
};
P.hyperbolicCosine = P.cosh = function() {
  var k, n, pr, rm, len, x = this, Ctor = x.constructor, one = new Ctor(1);
  if (!x.isFinite()) return new Ctor(x.s ? 1 / 0 : NaN);
  if (x.isZero()) return one;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
  Ctor.rounding = 1;
  len = x.d.length;
  if (len < 32) {
    k = Math.ceil(len / 3);
    n = (1 / tinyPow(4, k)).toString();
  } else {
    k = 16;
    n = "2.3283064365386962890625e-10";
  }
  x = taylorSeries(Ctor, 1, x.times(n), new Ctor(1), true);
  var cosh2_x, i = k, d8 = new Ctor(8);
  for (; i--; ) {
    cosh2_x = x.times(x);
    x = one.minus(cosh2_x.times(d8.minus(cosh2_x.times(d8))));
  }
  return finalise(x, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.hyperbolicSine = P.sinh = function() {
  var k, pr, rm, len, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
  Ctor.rounding = 1;
  len = x.d.length;
  if (len < 3) {
    x = taylorSeries(Ctor, 2, x, x, true);
  } else {
    k = 1.4 * Math.sqrt(len);
    k = k > 16 ? 16 : k | 0;
    x = x.times(1 / tinyPow(5, k));
    x = taylorSeries(Ctor, 2, x, x, true);
    var sinh2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
    for (; k--; ) {
      sinh2_x = x.times(x);
      x = x.times(d5.plus(sinh2_x.times(d16.times(sinh2_x).plus(d20))));
    }
  }
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(x, pr, rm, true);
};
P.hyperbolicTangent = P.tanh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(x.s);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 7;
  Ctor.rounding = 1;
  return divide(x.sinh(), x.cosh(), Ctor.precision = pr, Ctor.rounding = rm);
};
P.inverseCosine = P.acos = function() {
  var x = this, Ctor = x.constructor, k = x.abs().cmp(1), pr = Ctor.precision, rm = Ctor.rounding;
  if (k !== -1) {
    return k === 0 ? x.isNeg() ? getPi(Ctor, pr, rm) : new Ctor(0) : new Ctor(NaN);
  }
  if (x.isZero()) return getPi(Ctor, pr + 4, rm).times(0.5);
  Ctor.precision = pr + 6;
  Ctor.rounding = 1;
  x = new Ctor(1).minus(x).div(x.plus(1)).sqrt().atan();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(2);
};
P.inverseHyperbolicCosine = P.acosh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (x.lte(1)) return new Ctor(x.eq(1) ? 0 : NaN);
  if (!x.isFinite()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(Math.abs(x.e), x.sd()) + 4;
  Ctor.rounding = 1;
  external = false;
  x = x.times(x).minus(1).sqrt().plus(x);
  external = true;
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.ln();
};
P.inverseHyperbolicSine = P.asinh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 2 * Math.max(Math.abs(x.e), x.sd()) + 6;
  Ctor.rounding = 1;
  external = false;
  x = x.times(x).plus(1).sqrt().plus(x);
  external = true;
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.ln();
};
P.inverseHyperbolicTangent = P.atanh = function() {
  var pr, rm, wpr, xsd, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.e >= 0) return new Ctor(x.abs().eq(1) ? x.s / 0 : x.isZero() ? x : NaN);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  xsd = x.sd();
  if (Math.max(xsd, pr) < 2 * -x.e - 1) return finalise(new Ctor(x), pr, rm, true);
  Ctor.precision = wpr = xsd - x.e;
  x = divide(x.plus(1), new Ctor(1).minus(x), wpr + pr, 1);
  Ctor.precision = pr + 4;
  Ctor.rounding = 1;
  x = x.ln();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(0.5);
};
P.inverseSine = P.asin = function() {
  var halfPi, k, pr, rm, x = this, Ctor = x.constructor;
  if (x.isZero()) return new Ctor(x);
  k = x.abs().cmp(1);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (k !== -1) {
    if (k === 0) {
      halfPi = getPi(Ctor, pr + 4, rm).times(0.5);
      halfPi.s = x.s;
      return halfPi;
    }
    return new Ctor(NaN);
  }
  Ctor.precision = pr + 6;
  Ctor.rounding = 1;
  x = x.div(new Ctor(1).minus(x.times(x)).sqrt().plus(1)).atan();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(2);
};
P.inverseTangent = P.atan = function() {
  var i, j, k, n, px, t, r, wpr, x2, x = this, Ctor = x.constructor, pr = Ctor.precision, rm = Ctor.rounding;
  if (!x.isFinite()) {
    if (!x.s) return new Ctor(NaN);
    if (pr + 4 <= PI_PRECISION) {
      r = getPi(Ctor, pr + 4, rm).times(0.5);
      r.s = x.s;
      return r;
    }
  } else if (x.isZero()) {
    return new Ctor(x);
  } else if (x.abs().eq(1) && pr + 4 <= PI_PRECISION) {
    r = getPi(Ctor, pr + 4, rm).times(0.25);
    r.s = x.s;
    return r;
  }
  Ctor.precision = wpr = pr + 10;
  Ctor.rounding = 1;
  k = Math.min(28, wpr / LOG_BASE + 2 | 0);
  for (i = k; i; --i) x = x.div(x.times(x).plus(1).sqrt().plus(1));
  external = false;
  j = Math.ceil(wpr / LOG_BASE);
  n = 1;
  x2 = x.times(x);
  r = new Ctor(x);
  px = x;
  for (; i !== -1; ) {
    px = px.times(x2);
    t = r.minus(px.div(n += 2));
    px = px.times(x2);
    r = t.plus(px.div(n += 2));
    if (r.d[j] !== void 0) for (i = j; r.d[i] === t.d[i] && i--; ) ;
  }
  if (k) r = r.times(2 << k - 1);
  external = true;
  return finalise(r, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.isFinite = function() {
  return !!this.d;
};
P.isInteger = P.isInt = function() {
  return !!this.d && mathfloor(this.e / LOG_BASE) > this.d.length - 2;
};
P.isNaN = function() {
  return !this.s;
};
P.isNegative = P.isNeg = function() {
  return this.s < 0;
};
P.isPositive = P.isPos = function() {
  return this.s > 0;
};
P.isZero = function() {
  return !!this.d && this.d[0] === 0;
};
P.lessThan = P.lt = function(y) {
  return this.cmp(y) < 0;
};
P.lessThanOrEqualTo = P.lte = function(y) {
  return this.cmp(y) < 1;
};
P.logarithm = P.log = function(base) {
  var isBase10, d, denominator, k, inf, num, sd, r, arg = this, Ctor = arg.constructor, pr = Ctor.precision, rm = Ctor.rounding, guard = 5;
  if (base == null) {
    base = new Ctor(10);
    isBase10 = true;
  } else {
    base = new Ctor(base);
    d = base.d;
    if (base.s < 0 || !d || !d[0] || base.eq(1)) return new Ctor(NaN);
    isBase10 = base.eq(10);
  }
  d = arg.d;
  if (arg.s < 0 || !d || !d[0] || arg.eq(1)) {
    return new Ctor(d && !d[0] ? -1 / 0 : arg.s != 1 ? NaN : d ? 0 : 1 / 0);
  }
  if (isBase10) {
    if (d.length > 1) {
      inf = true;
    } else {
      for (k = d[0]; k % 10 === 0; ) k /= 10;
      inf = k !== 1;
    }
  }
  external = false;
  sd = pr + guard;
  num = naturalLogarithm(arg, sd);
  denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
  r = divide(num, denominator, sd, 1);
  if (checkRoundingDigits(r.d, k = pr, rm)) {
    do {
      sd += 10;
      num = naturalLogarithm(arg, sd);
      denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
      r = divide(num, denominator, sd, 1);
      if (!inf) {
        if (+digitsToString(r.d).slice(k + 1, k + 15) + 1 == 1e14) {
          r = finalise(r, pr + 1, 0);
        }
        break;
      }
    } while (checkRoundingDigits(r.d, k += 10, rm));
  }
  external = true;
  return finalise(r, pr, rm);
};
P.minus = P.sub = function(y) {
  var d, e, i, j, k, len, pr, rm, xd, xe, xLTy, yd, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.d) {
    if (!x.s || !y.s) y = new Ctor(NaN);
    else if (x.d) y.s = -y.s;
    else y = new Ctor(y.d || x.s !== y.s ? x : NaN);
    return y;
  }
  if (x.s != y.s) {
    y.s = -y.s;
    return x.plus(y);
  }
  xd = x.d;
  yd = y.d;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (!xd[0] || !yd[0]) {
    if (yd[0]) y.s = -y.s;
    else if (xd[0]) y = new Ctor(x);
    else return new Ctor(rm === 3 ? -0 : 0);
    return external ? finalise(y, pr, rm) : y;
  }
  e = mathfloor(y.e / LOG_BASE);
  xe = mathfloor(x.e / LOG_BASE);
  xd = xd.slice();
  k = xe - e;
  if (k) {
    xLTy = k < 0;
    if (xLTy) {
      d = xd;
      k = -k;
      len = yd.length;
    } else {
      d = yd;
      e = xe;
      len = xd.length;
    }
    i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
    if (k > i) {
      k = i;
      d.length = 1;
    }
    d.reverse();
    for (i = k; i--; ) d.push(0);
    d.reverse();
  } else {
    i = xd.length;
    len = yd.length;
    xLTy = i < len;
    if (xLTy) len = i;
    for (i = 0; i < len; i++) {
      if (xd[i] != yd[i]) {
        xLTy = xd[i] < yd[i];
        break;
      }
    }
    k = 0;
  }
  if (xLTy) {
    d = xd;
    xd = yd;
    yd = d;
    y.s = -y.s;
  }
  len = xd.length;
  for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
  for (i = yd.length; i > k; ) {
    if (xd[--i] < yd[i]) {
      for (j = i; j && xd[--j] === 0; ) xd[j] = BASE - 1;
      --xd[j];
      xd[i] += BASE;
    }
    xd[i] -= yd[i];
  }
  for (; xd[--len] === 0; ) xd.pop();
  for (; xd[0] === 0; xd.shift()) --e;
  if (!xd[0]) return new Ctor(rm === 3 ? -0 : 0);
  y.d = xd;
  y.e = getBase10Exponent(xd, e);
  return external ? finalise(y, pr, rm) : y;
};
P.modulo = P.mod = function(y) {
  var q, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.s || y.d && !y.d[0]) return new Ctor(NaN);
  if (!y.d || x.d && !x.d[0]) {
    return finalise(new Ctor(x), Ctor.precision, Ctor.rounding);
  }
  external = false;
  if (Ctor.modulo == 9) {
    q = divide(x, y.abs(), 0, 3, 1);
    q.s *= y.s;
  } else {
    q = divide(x, y, 0, Ctor.modulo, 1);
  }
  q = q.times(y);
  external = true;
  return x.minus(q);
};
P.naturalExponential = P.exp = function() {
  return naturalExponential(this);
};
P.naturalLogarithm = P.ln = function() {
  return naturalLogarithm(this);
};
P.negated = P.neg = function() {
  var x = new this.constructor(this);
  x.s = -x.s;
  return finalise(x);
};
P.plus = P.add = function(y) {
  var carry, d, e, i, k, len, pr, rm, xd, yd, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.d) {
    if (!x.s || !y.s) y = new Ctor(NaN);
    else if (!x.d) y = new Ctor(y.d || x.s === y.s ? x : NaN);
    return y;
  }
  if (x.s != y.s) {
    y.s = -y.s;
    return x.minus(y);
  }
  xd = x.d;
  yd = y.d;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (!xd[0] || !yd[0]) {
    if (!yd[0]) y = new Ctor(x);
    return external ? finalise(y, pr, rm) : y;
  }
  k = mathfloor(x.e / LOG_BASE);
  e = mathfloor(y.e / LOG_BASE);
  xd = xd.slice();
  i = k - e;
  if (i) {
    if (i < 0) {
      d = xd;
      i = -i;
      len = yd.length;
    } else {
      d = yd;
      e = k;
      len = xd.length;
    }
    k = Math.ceil(pr / LOG_BASE);
    len = k > len ? k + 1 : len + 1;
    if (i > len) {
      i = len;
      d.length = 1;
    }
    d.reverse();
    for (; i--; ) d.push(0);
    d.reverse();
  }
  len = xd.length;
  i = yd.length;
  if (len - i < 0) {
    i = len;
    d = yd;
    yd = xd;
    xd = d;
  }
  for (carry = 0; i; ) {
    carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
    xd[i] %= BASE;
  }
  if (carry) {
    xd.unshift(carry);
    ++e;
  }
  for (len = xd.length; xd[--len] == 0; ) xd.pop();
  y.d = xd;
  y.e = getBase10Exponent(xd, e);
  return external ? finalise(y, pr, rm) : y;
};
P.precision = P.sd = function(z) {
  var k, x = this;
  if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
  if (x.d) {
    k = getPrecision(x.d);
    if (z && x.e + 1 > k) k = x.e + 1;
  } else {
    k = NaN;
  }
  return k;
};
P.round = function() {
  var x = this, Ctor = x.constructor;
  return finalise(new Ctor(x), x.e + 1, Ctor.rounding);
};
P.sine = P.sin = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
  Ctor.rounding = 1;
  x = sine(Ctor, toLessThanHalfPi(Ctor, x));
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant > 2 ? x.neg() : x, pr, rm, true);
};
P.squareRoot = P.sqrt = function() {
  var m, n, sd, r, rep, t, x = this, d = x.d, e = x.e, s = x.s, Ctor = x.constructor;
  if (s !== 1 || !d || !d[0]) {
    return new Ctor(!s || s < 0 && (!d || d[0]) ? NaN : d ? x : 1 / 0);
  }
  external = false;
  s = Math.sqrt(+x);
  if (s == 0 || s == 1 / 0) {
    n = digitsToString(d);
    if ((n.length + e) % 2 == 0) n += "0";
    s = Math.sqrt(n);
    e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
    if (s == 1 / 0) {
      n = "5e" + e;
    } else {
      n = s.toExponential();
      n = n.slice(0, n.indexOf("e") + 1) + e;
    }
    r = new Ctor(n);
  } else {
    r = new Ctor(s.toString());
  }
  sd = (e = Ctor.precision) + 3;
  for (; ; ) {
    t = r;
    r = t.plus(divide(x, t, sd + 2, 1)).times(0.5);
    if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
      n = n.slice(sd - 3, sd + 1);
      if (n == "9999" || !rep && n == "4999") {
        if (!rep) {
          finalise(t, e + 1, 0);
          if (t.times(t).eq(x)) {
            r = t;
            break;
          }
        }
        sd += 4;
        rep = 1;
      } else {
        if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
          finalise(r, e + 1, 1);
          m = !r.times(r).eq(x);
        }
        break;
      }
    }
  }
  external = true;
  return finalise(r, e, Ctor.rounding, m);
};
P.tangent = P.tan = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 10;
  Ctor.rounding = 1;
  x = x.sin();
  x.s = 1;
  x = divide(x, new Ctor(1).minus(x.times(x)).sqrt(), pr + 10, 0);
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant == 2 || quadrant == 4 ? x.neg() : x, pr, rm, true);
};
P.times = P.mul = function(y) {
  var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
  y.s *= x.s;
  if (!xd || !xd[0] || !yd || !yd[0]) {
    return new Ctor(!y.s || xd && !xd[0] && !yd || yd && !yd[0] && !xd ? NaN : !xd || !yd ? y.s / 0 : y.s * 0);
  }
  e = mathfloor(x.e / LOG_BASE) + mathfloor(y.e / LOG_BASE);
  xdL = xd.length;
  ydL = yd.length;
  if (xdL < ydL) {
    r = xd;
    xd = yd;
    yd = r;
    rL = xdL;
    xdL = ydL;
    ydL = rL;
  }
  r = [];
  rL = xdL + ydL;
  for (i = rL; i--; ) r.push(0);
  for (i = ydL; --i >= 0; ) {
    carry = 0;
    for (k = xdL + i; k > i; ) {
      t = r[k] + yd[i] * xd[k - i - 1] + carry;
      r[k--] = t % BASE | 0;
      carry = t / BASE | 0;
    }
    r[k] = (r[k] + carry) % BASE | 0;
  }
  for (; !r[--rL]; ) r.pop();
  if (carry) ++e;
  else r.shift();
  y.d = r;
  y.e = getBase10Exponent(r, e);
  return external ? finalise(y, Ctor.precision, Ctor.rounding) : y;
};
P.toBinary = function(sd, rm) {
  return toStringBinary(this, 2, sd, rm);
};
P.toDecimalPlaces = P.toDP = function(dp, rm) {
  var x = this, Ctor = x.constructor;
  x = new Ctor(x);
  if (dp === void 0) return x;
  checkInt32(dp, 0, MAX_DIGITS);
  if (rm === void 0) rm = Ctor.rounding;
  else checkInt32(rm, 0, 8);
  return finalise(x, dp + x.e + 1, rm);
};
P.toExponential = function(dp, rm) {
  var str, x = this, Ctor = x.constructor;
  if (dp === void 0) {
    str = finiteToString(x, true);
  } else {
    checkInt32(dp, 0, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    x = finalise(new Ctor(x), dp + 1, rm);
    str = finiteToString(x, true, dp + 1);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFixed = function(dp, rm) {
  var str, y, x = this, Ctor = x.constructor;
  if (dp === void 0) {
    str = finiteToString(x);
  } else {
    checkInt32(dp, 0, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    y = finalise(new Ctor(x), dp + x.e + 1, rm);
    str = finiteToString(y, false, dp + y.e + 1);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFraction = function(maxD) {
  var d, d0, d1, d2, e, k, n, n0, n1, pr, q, r, x = this, xd = x.d, Ctor = x.constructor;
  if (!xd) return new Ctor(x);
  n1 = d0 = new Ctor(1);
  d1 = n0 = new Ctor(0);
  d = new Ctor(d1);
  e = d.e = getPrecision(xd) - x.e - 1;
  k = e % LOG_BASE;
  d.d[0] = mathpow(10, k < 0 ? LOG_BASE + k : k);
  if (maxD == null) {
    maxD = e > 0 ? d : n1;
  } else {
    n = new Ctor(maxD);
    if (!n.isInt() || n.lt(n1)) throw Error(invalidArgument + n);
    maxD = n.gt(d) ? e > 0 ? d : n1 : n;
  }
  external = false;
  n = new Ctor(digitsToString(xd));
  pr = Ctor.precision;
  Ctor.precision = e = xd.length * LOG_BASE * 2;
  for (; ; ) {
    q = divide(n, d, 0, 1, 1);
    d2 = d0.plus(q.times(d1));
    if (d2.cmp(maxD) == 1) break;
    d0 = d1;
    d1 = d2;
    d2 = n1;
    n1 = n0.plus(q.times(d2));
    n0 = d2;
    d2 = d;
    d = n.minus(q.times(d2));
    n = d2;
  }
  d2 = divide(maxD.minus(d0), d1, 0, 1, 1);
  n0 = n0.plus(d2.times(n1));
  d0 = d0.plus(d2.times(d1));
  n0.s = n1.s = x.s;
  r = divide(n1, d1, e, 1).minus(x).abs().cmp(divide(n0, d0, e, 1).minus(x).abs()) < 1 ? [n1, d1] : [n0, d0];
  Ctor.precision = pr;
  external = true;
  return r;
};
P.toHexadecimal = P.toHex = function(sd, rm) {
  return toStringBinary(this, 16, sd, rm);
};
P.toNearest = function(y, rm) {
  var x = this, Ctor = x.constructor;
  x = new Ctor(x);
  if (y == null) {
    if (!x.d) return x;
    y = new Ctor(1);
    rm = Ctor.rounding;
  } else {
    y = new Ctor(y);
    if (rm === void 0) {
      rm = Ctor.rounding;
    } else {
      checkInt32(rm, 0, 8);
    }
    if (!x.d) return y.s ? x : y;
    if (!y.d) {
      if (y.s) y.s = x.s;
      return y;
    }
  }
  if (y.d[0]) {
    external = false;
    x = divide(x, y, 0, rm, 1).times(y);
    external = true;
    finalise(x);
  } else {
    y.s = x.s;
    x = y;
  }
  return x;
};
P.toNumber = function() {
  return +this;
};
P.toOctal = function(sd, rm) {
  return toStringBinary(this, 8, sd, rm);
};
P.toPower = P.pow = function(y) {
  var e, k, pr, r, rm, s, x = this, Ctor = x.constructor, yn = +(y = new Ctor(y));
  if (!x.d || !y.d || !x.d[0] || !y.d[0]) return new Ctor(mathpow(+x, yn));
  x = new Ctor(x);
  if (x.eq(1)) return x;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (y.eq(1)) return finalise(x, pr, rm);
  e = mathfloor(y.e / LOG_BASE);
  if (e >= y.d.length - 1 && (k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
    r = intPow(Ctor, x, k, pr);
    return y.s < 0 ? new Ctor(1).div(r) : finalise(r, pr, rm);
  }
  s = x.s;
  if (s < 0) {
    if (e < y.d.length - 1) return new Ctor(NaN);
    if ((y.d[e] & 1) == 0) s = 1;
    if (x.e == 0 && x.d[0] == 1 && x.d.length == 1) {
      x.s = s;
      return x;
    }
  }
  k = mathpow(+x, yn);
  e = k == 0 || !isFinite(k) ? mathfloor(yn * (Math.log("0." + digitsToString(x.d)) / Math.LN10 + x.e + 1)) : new Ctor(k + "").e;
  if (e > Ctor.maxE + 1 || e < Ctor.minE - 1) return new Ctor(e > 0 ? s / 0 : 0);
  external = false;
  Ctor.rounding = x.s = 1;
  k = Math.min(12, (e + "").length);
  r = naturalExponential(y.times(naturalLogarithm(x, pr + k)), pr);
  if (r.d) {
    r = finalise(r, pr + 5, 1);
    if (checkRoundingDigits(r.d, pr, rm)) {
      e = pr + 10;
      r = finalise(naturalExponential(y.times(naturalLogarithm(x, e + k)), e), e + 5, 1);
      if (+digitsToString(r.d).slice(pr + 1, pr + 15) + 1 == 1e14) {
        r = finalise(r, pr + 1, 0);
      }
    }
  }
  r.s = s;
  external = true;
  Ctor.rounding = rm;
  return finalise(r, pr, rm);
};
P.toPrecision = function(sd, rm) {
  var str, x = this, Ctor = x.constructor;
  if (sd === void 0) {
    str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  } else {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    x = finalise(new Ctor(x), sd, rm);
    str = finiteToString(x, sd <= x.e || x.e <= Ctor.toExpNeg, sd);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toSignificantDigits = P.toSD = function(sd, rm) {
  var x = this, Ctor = x.constructor;
  if (sd === void 0) {
    sd = Ctor.precision;
    rm = Ctor.rounding;
  } else {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
  }
  return finalise(new Ctor(x), sd, rm);
};
P.toString = function() {
  var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.truncated = P.trunc = function() {
  return finalise(new this.constructor(this), this.e + 1, 1);
};
P.valueOf = P.toJSON = function() {
  var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  return x.isNeg() ? "-" + str : str;
};
function digitsToString(d) {
  var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
  if (indexOfLastWord > 0) {
    str += w;
    for (i = 1; i < indexOfLastWord; i++) {
      ws = d[i] + "";
      k = LOG_BASE - ws.length;
      if (k) str += getZeroString(k);
      str += ws;
    }
    w = d[i];
    ws = w + "";
    k = LOG_BASE - ws.length;
    if (k) str += getZeroString(k);
  } else if (w === 0) {
    return "0";
  }
  for (; w % 10 === 0; ) w /= 10;
  return str + w;
}
function checkInt32(i, min2, max2) {
  if (i !== ~~i || i < min2 || i > max2) {
    throw Error(invalidArgument + i);
  }
}
function checkRoundingDigits(d, i, rm, repeating) {
  var di, k, r, rd;
  for (k = d[0]; k >= 10; k /= 10) --i;
  if (--i < 0) {
    i += LOG_BASE;
    di = 0;
  } else {
    di = Math.ceil((i + 1) / LOG_BASE);
    i %= LOG_BASE;
  }
  k = mathpow(10, LOG_BASE - i);
  rd = d[di] % k | 0;
  if (repeating == null) {
    if (i < 3) {
      if (i == 0) rd = rd / 100 | 0;
      else if (i == 1) rd = rd / 10 | 0;
      r = rm < 4 && rd == 99999 || rm > 3 && rd == 49999 || rd == 5e4 || rd == 0;
    } else {
      r = (rm < 4 && rd + 1 == k || rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 100 | 0) == mathpow(10, i - 2) - 1 || (rd == k / 2 || rd == 0) && (d[di + 1] / k / 100 | 0) == 0;
    }
  } else {
    if (i < 4) {
      if (i == 0) rd = rd / 1e3 | 0;
      else if (i == 1) rd = rd / 100 | 0;
      else if (i == 2) rd = rd / 10 | 0;
      r = (repeating || rm < 4) && rd == 9999 || !repeating && rm > 3 && rd == 4999;
    } else {
      r = ((repeating || rm < 4) && rd + 1 == k || !repeating && rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 1e3 | 0) == mathpow(10, i - 3) - 1;
    }
  }
  return r;
}
function convertBase(str, baseIn, baseOut) {
  var j, arr = [0], arrL, i = 0, strL = str.length;
  for (; i < strL; ) {
    for (arrL = arr.length; arrL--; ) arr[arrL] *= baseIn;
    arr[0] += NUMERALS.indexOf(str.charAt(i++));
    for (j = 0; j < arr.length; j++) {
      if (arr[j] > baseOut - 1) {
        if (arr[j + 1] === void 0) arr[j + 1] = 0;
        arr[j + 1] += arr[j] / baseOut | 0;
        arr[j] %= baseOut;
      }
    }
  }
  return arr.reverse();
}
function cosine(Ctor, x) {
  var k, len, y;
  if (x.isZero()) return x;
  len = x.d.length;
  if (len < 32) {
    k = Math.ceil(len / 3);
    y = (1 / tinyPow(4, k)).toString();
  } else {
    k = 16;
    y = "2.3283064365386962890625e-10";
  }
  Ctor.precision += k;
  x = taylorSeries(Ctor, 1, x.times(y), new Ctor(1));
  for (var i = k; i--; ) {
    var cos2x = x.times(x);
    x = cos2x.times(cos2x).minus(cos2x).times(8).plus(1);
  }
  Ctor.precision -= k;
  return x;
}
var divide = /* @__PURE__ */ (function() {
  function multiplyInteger(x, k, base) {
    var temp, carry = 0, i = x.length;
    for (x = x.slice(); i--; ) {
      temp = x[i] * k + carry;
      x[i] = temp % base | 0;
      carry = temp / base | 0;
    }
    if (carry) x.unshift(carry);
    return x;
  }
  function compare(a, b, aL, bL) {
    var i, r;
    if (aL != bL) {
      r = aL > bL ? 1 : -1;
    } else {
      for (i = r = 0; i < aL; i++) {
        if (a[i] != b[i]) {
          r = a[i] > b[i] ? 1 : -1;
          break;
        }
      }
    }
    return r;
  }
  function subtract(a, b, aL, base) {
    var i = 0;
    for (; aL--; ) {
      a[aL] -= i;
      i = a[aL] < b[aL] ? 1 : 0;
      a[aL] = i * base + a[aL] - b[aL];
    }
    for (; !a[0] && a.length > 1; ) a.shift();
  }
  return function(x, y, pr, rm, dp, base) {
    var cmp, e, i, k, logBase, more, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign2 = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
    if (!xd || !xd[0] || !yd || !yd[0]) {
      return new Ctor(
        // Return NaN if either NaN, or both Infinity or 0.
        !x.s || !y.s || (xd ? yd && xd[0] == yd[0] : !yd) ? NaN : (
          // Return ±0 if x is 0 or y is ±Infinity, or return ±Infinity as y is 0.
          xd && xd[0] == 0 || !yd ? sign2 * 0 : sign2 / 0
        )
      );
    }
    if (base) {
      logBase = 1;
      e = x.e - y.e;
    } else {
      base = BASE;
      logBase = LOG_BASE;
      e = mathfloor(x.e / logBase) - mathfloor(y.e / logBase);
    }
    yL = yd.length;
    xL = xd.length;
    q = new Ctor(sign2);
    qd = q.d = [];
    for (i = 0; yd[i] == (xd[i] || 0); i++) ;
    if (yd[i] > (xd[i] || 0)) e--;
    if (pr == null) {
      sd = pr = Ctor.precision;
      rm = Ctor.rounding;
    } else if (dp) {
      sd = pr + (x.e - y.e) + 1;
    } else {
      sd = pr;
    }
    if (sd < 0) {
      qd.push(1);
      more = true;
    } else {
      sd = sd / logBase + 2 | 0;
      i = 0;
      if (yL == 1) {
        k = 0;
        yd = yd[0];
        sd++;
        for (; (i < xL || k) && sd--; i++) {
          t = k * base + (xd[i] || 0);
          qd[i] = t / yd | 0;
          k = t % yd | 0;
        }
        more = k || i < xL;
      } else {
        k = base / (yd[0] + 1) | 0;
        if (k > 1) {
          yd = multiplyInteger(yd, k, base);
          xd = multiplyInteger(xd, k, base);
          yL = yd.length;
          xL = xd.length;
        }
        xi = yL;
        rem = xd.slice(0, yL);
        remL = rem.length;
        for (; remL < yL; ) rem[remL++] = 0;
        yz = yd.slice();
        yz.unshift(0);
        yd0 = yd[0];
        if (yd[1] >= base / 2) ++yd0;
        do {
          k = 0;
          cmp = compare(yd, rem, yL, remL);
          if (cmp < 0) {
            rem0 = rem[0];
            if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
            k = rem0 / yd0 | 0;
            if (k > 1) {
              if (k >= base) k = base - 1;
              prod = multiplyInteger(yd, k, base);
              prodL = prod.length;
              remL = rem.length;
              cmp = compare(prod, rem, prodL, remL);
              if (cmp == 1) {
                k--;
                subtract(prod, yL < prodL ? yz : yd, prodL, base);
              }
            } else {
              if (k == 0) cmp = k = 1;
              prod = yd.slice();
            }
            prodL = prod.length;
            if (prodL < remL) prod.unshift(0);
            subtract(rem, prod, remL, base);
            if (cmp == -1) {
              remL = rem.length;
              cmp = compare(yd, rem, yL, remL);
              if (cmp < 1) {
                k++;
                subtract(rem, yL < remL ? yz : yd, remL, base);
              }
            }
            remL = rem.length;
          } else if (cmp === 0) {
            k++;
            rem = [0];
          }
          qd[i++] = k;
          if (cmp && rem[0]) {
            rem[remL++] = xd[xi] || 0;
          } else {
            rem = [xd[xi]];
            remL = 1;
          }
        } while ((xi++ < xL || rem[0] !== void 0) && sd--);
        more = rem[0] !== void 0;
      }
      if (!qd[0]) qd.shift();
    }
    if (logBase == 1) {
      q.e = e;
      inexact = more;
    } else {
      for (i = 1, k = qd[0]; k >= 10; k /= 10) i++;
      q.e = i + e * logBase - 1;
      finalise(q, dp ? pr + q.e + 1 : pr, rm, more);
    }
    return q;
  };
})();
function finalise(x, sd, rm, isTruncated) {
  var digits, i, j, k, rd, roundUp, w, xd, xdi, Ctor = x.constructor;
  out: if (sd != null) {
    xd = x.d;
    if (!xd) return x;
    for (digits = 1, k = xd[0]; k >= 10; k /= 10) digits++;
    i = sd - digits;
    if (i < 0) {
      i += LOG_BASE;
      j = sd;
      w = xd[xdi = 0];
      rd = w / mathpow(10, digits - j - 1) % 10 | 0;
    } else {
      xdi = Math.ceil((i + 1) / LOG_BASE);
      k = xd.length;
      if (xdi >= k) {
        if (isTruncated) {
          for (; k++ <= xdi; ) xd.push(0);
          w = rd = 0;
          digits = 1;
          i %= LOG_BASE;
          j = i - LOG_BASE + 1;
        } else {
          break out;
        }
      } else {
        w = k = xd[xdi];
        for (digits = 1; k >= 10; k /= 10) digits++;
        i %= LOG_BASE;
        j = i - LOG_BASE + digits;
        rd = j < 0 ? 0 : w / mathpow(10, digits - j - 1) % 10 | 0;
      }
    }
    isTruncated = isTruncated || sd < 0 || xd[xdi + 1] !== void 0 || (j < 0 ? w : w % mathpow(10, digits - j - 1));
    roundUp = rm < 4 ? (rd || isTruncated) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || isTruncated || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
    (i > 0 ? j > 0 ? w / mathpow(10, digits - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
    if (sd < 1 || !xd[0]) {
      xd.length = 0;
      if (roundUp) {
        sd -= x.e + 1;
        xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
        x.e = -sd || 0;
      } else {
        xd[0] = x.e = 0;
      }
      return x;
    }
    if (i == 0) {
      xd.length = xdi;
      k = 1;
      xdi--;
    } else {
      xd.length = xdi + 1;
      k = mathpow(10, LOG_BASE - i);
      xd[xdi] = j > 0 ? (w / mathpow(10, digits - j) % mathpow(10, j) | 0) * k : 0;
    }
    if (roundUp) {
      for (; ; ) {
        if (xdi == 0) {
          for (i = 1, j = xd[0]; j >= 10; j /= 10) i++;
          j = xd[0] += k;
          for (k = 1; j >= 10; j /= 10) k++;
          if (i != k) {
            x.e++;
            if (xd[0] == BASE) xd[0] = 1;
          }
          break;
        } else {
          xd[xdi] += k;
          if (xd[xdi] != BASE) break;
          xd[xdi--] = 0;
          k = 1;
        }
      }
    }
    for (i = xd.length; xd[--i] === 0; ) xd.pop();
  }
  if (external) {
    if (x.e > Ctor.maxE) {
      x.d = null;
      x.e = NaN;
    } else if (x.e < Ctor.minE) {
      x.e = 0;
      x.d = [0];
    }
  }
  return x;
}
function finiteToString(x, isExp, sd) {
  if (!x.isFinite()) return nonFiniteToString(x);
  var k, e = x.e, str = digitsToString(x.d), len = str.length;
  if (isExp) {
    if (sd && (k = sd - len) > 0) {
      str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
    } else if (len > 1) {
      str = str.charAt(0) + "." + str.slice(1);
    }
    str = str + (x.e < 0 ? "e" : "e+") + x.e;
  } else if (e < 0) {
    str = "0." + getZeroString(-e - 1) + str;
    if (sd && (k = sd - len) > 0) str += getZeroString(k);
  } else if (e >= len) {
    str += getZeroString(e + 1 - len);
    if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
  } else {
    if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
    if (sd && (k = sd - len) > 0) {
      if (e + 1 === len) str += ".";
      str += getZeroString(k);
    }
  }
  return str;
}
function getBase10Exponent(digits, e) {
  var w = digits[0];
  for (e *= LOG_BASE; w >= 10; w /= 10) e++;
  return e;
}
function getLn10(Ctor, sd, pr) {
  if (sd > LN10_PRECISION) {
    external = true;
    if (pr) Ctor.precision = pr;
    throw Error(precisionLimitExceeded);
  }
  return finalise(new Ctor(LN10), sd, 1, true);
}
function getPi(Ctor, sd, rm) {
  if (sd > PI_PRECISION) throw Error(precisionLimitExceeded);
  return finalise(new Ctor(PI), sd, rm, true);
}
function getPrecision(digits) {
  var w = digits.length - 1, len = w * LOG_BASE + 1;
  w = digits[w];
  if (w) {
    for (; w % 10 == 0; w /= 10) len--;
    for (w = digits[0]; w >= 10; w /= 10) len++;
  }
  return len;
}
function getZeroString(k) {
  var zs = "";
  for (; k--; ) zs += "0";
  return zs;
}
function intPow(Ctor, x, n, pr) {
  var isTruncated, r = new Ctor(1), k = Math.ceil(pr / LOG_BASE + 4);
  external = false;
  for (; ; ) {
    if (n % 2) {
      r = r.times(x);
      if (truncate(r.d, k)) isTruncated = true;
    }
    n = mathfloor(n / 2);
    if (n === 0) {
      n = r.d.length - 1;
      if (isTruncated && r.d[n] === 0) ++r.d[n];
      break;
    }
    x = x.times(x);
    truncate(x.d, k);
  }
  external = true;
  return r;
}
function isOdd(n) {
  return n.d[n.d.length - 1] & 1;
}
function maxOrMin(Ctor, args, n) {
  var k, y, x = new Ctor(args[0]), i = 0;
  for (; ++i < args.length; ) {
    y = new Ctor(args[i]);
    if (!y.s) {
      x = y;
      break;
    }
    k = x.cmp(y);
    if (k === n || k === 0 && x.s === n) {
      x = y;
    }
  }
  return x;
}
function naturalExponential(x, sd) {
  var denominator, guard, j, pow2, sum2, t, wpr, rep = 0, i = 0, k = 0, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
  if (!x.d || !x.d[0] || x.e > 17) {
    return new Ctor(x.d ? !x.d[0] ? 1 : x.s < 0 ? 0 : 1 / 0 : x.s ? x.s < 0 ? 0 : x : 0 / 0);
  }
  if (sd == null) {
    external = false;
    wpr = pr;
  } else {
    wpr = sd;
  }
  t = new Ctor(0.03125);
  while (x.e > -2) {
    x = x.times(t);
    k += 5;
  }
  guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
  wpr += guard;
  denominator = pow2 = sum2 = new Ctor(1);
  Ctor.precision = wpr;
  for (; ; ) {
    pow2 = finalise(pow2.times(x), wpr, 1);
    denominator = denominator.times(++i);
    t = sum2.plus(divide(pow2, denominator, wpr, 1));
    if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
      j = k;
      while (j--) sum2 = finalise(sum2.times(sum2), wpr, 1);
      if (sd == null) {
        if (rep < 3 && checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
          Ctor.precision = wpr += 10;
          denominator = pow2 = t = new Ctor(1);
          i = 0;
          rep++;
        } else {
          return finalise(sum2, Ctor.precision = pr, rm, external = true);
        }
      } else {
        Ctor.precision = pr;
        return sum2;
      }
    }
    sum2 = t;
  }
}
function naturalLogarithm(y, sd) {
  var c, c0, denominator, e, numerator, rep, sum2, t, wpr, x1, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
  if (x.s < 0 || !xd || !xd[0] || !x.e && xd[0] == 1 && xd.length == 1) {
    return new Ctor(xd && !xd[0] ? -1 / 0 : x.s != 1 ? NaN : xd ? 0 : x);
  }
  if (sd == null) {
    external = false;
    wpr = pr;
  } else {
    wpr = sd;
  }
  Ctor.precision = wpr += guard;
  c = digitsToString(xd);
  c0 = c.charAt(0);
  if (Math.abs(e = x.e) < 15e14) {
    while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
      x = x.times(y);
      c = digitsToString(x.d);
      c0 = c.charAt(0);
      n++;
    }
    e = x.e;
    if (c0 > 1) {
      x = new Ctor("0." + c);
      e++;
    } else {
      x = new Ctor(c0 + "." + c.slice(1));
    }
  } else {
    t = getLn10(Ctor, wpr + 2, pr).times(e + "");
    x = naturalLogarithm(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
    Ctor.precision = pr;
    return sd == null ? finalise(x, pr, rm, external = true) : x;
  }
  x1 = x;
  sum2 = numerator = x = divide(x.minus(1), x.plus(1), wpr, 1);
  x2 = finalise(x.times(x), wpr, 1);
  denominator = 3;
  for (; ; ) {
    numerator = finalise(numerator.times(x2), wpr, 1);
    t = sum2.plus(divide(numerator, new Ctor(denominator), wpr, 1));
    if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
      sum2 = sum2.times(2);
      if (e !== 0) sum2 = sum2.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
      sum2 = divide(sum2, new Ctor(n), wpr, 1);
      if (sd == null) {
        if (checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
          Ctor.precision = wpr += guard;
          t = numerator = x = divide(x1.minus(1), x1.plus(1), wpr, 1);
          x2 = finalise(x.times(x), wpr, 1);
          denominator = rep = 1;
        } else {
          return finalise(sum2, Ctor.precision = pr, rm, external = true);
        }
      } else {
        Ctor.precision = pr;
        return sum2;
      }
    }
    sum2 = t;
    denominator += 2;
  }
}
function nonFiniteToString(x) {
  return String(x.s * x.s / 0);
}
function parseDecimal(x, str) {
  var e, i, len;
  if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
  if ((i = str.search(/e/i)) > 0) {
    if (e < 0) e = i;
    e += +str.slice(i + 1);
    str = str.substring(0, i);
  } else if (e < 0) {
    e = str.length;
  }
  for (i = 0; str.charCodeAt(i) === 48; i++) ;
  for (len = str.length; str.charCodeAt(len - 1) === 48; --len) ;
  str = str.slice(i, len);
  if (str) {
    len -= i;
    x.e = e = e - i - 1;
    x.d = [];
    i = (e + 1) % LOG_BASE;
    if (e < 0) i += LOG_BASE;
    if (i < len) {
      if (i) x.d.push(+str.slice(0, i));
      for (len -= LOG_BASE; i < len; ) x.d.push(+str.slice(i, i += LOG_BASE));
      str = str.slice(i);
      i = LOG_BASE - str.length;
    } else {
      i -= len;
    }
    for (; i--; ) str += "0";
    x.d.push(+str);
    if (external) {
      if (x.e > x.constructor.maxE) {
        x.d = null;
        x.e = NaN;
      } else if (x.e < x.constructor.minE) {
        x.e = 0;
        x.d = [0];
      }
    }
  } else {
    x.e = 0;
    x.d = [0];
  }
  return x;
}
function parseOther(x, str) {
  var base, Ctor, divisor, i, isFloat, len, p, xd, xe;
  if (str.indexOf("_") > -1) {
    str = str.replace(/(\d)_(?=\d)/g, "$1");
    if (isDecimal.test(str)) return parseDecimal(x, str);
  } else if (str === "Infinity" || str === "NaN") {
    if (!+str) x.s = NaN;
    x.e = NaN;
    x.d = null;
    return x;
  }
  if (isHex.test(str)) {
    base = 16;
    str = str.toLowerCase();
  } else if (isBinary.test(str)) {
    base = 2;
  } else if (isOctal.test(str)) {
    base = 8;
  } else {
    throw Error(invalidArgument + str);
  }
  i = str.search(/p/i);
  if (i > 0) {
    p = +str.slice(i + 1);
    str = str.substring(2, i);
  } else {
    str = str.slice(2);
  }
  i = str.indexOf(".");
  isFloat = i >= 0;
  Ctor = x.constructor;
  if (isFloat) {
    str = str.replace(".", "");
    len = str.length;
    i = len - i;
    divisor = intPow(Ctor, new Ctor(base), i, i * 2);
  }
  xd = convertBase(str, base, BASE);
  xe = xd.length - 1;
  for (i = xe; xd[i] === 0; --i) xd.pop();
  if (i < 0) return new Ctor(x.s * 0);
  x.e = getBase10Exponent(xd, xe);
  x.d = xd;
  external = false;
  if (isFloat) x = divide(x, divisor, len * 4);
  if (p) x = x.times(Math.abs(p) < 54 ? mathpow(2, p) : Decimal.pow(2, p));
  external = true;
  return x;
}
function sine(Ctor, x) {
  var k, len = x.d.length;
  if (len < 3) {
    return x.isZero() ? x : taylorSeries(Ctor, 2, x, x);
  }
  k = 1.4 * Math.sqrt(len);
  k = k > 16 ? 16 : k | 0;
  x = x.times(1 / tinyPow(5, k));
  x = taylorSeries(Ctor, 2, x, x);
  var sin2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
  for (; k--; ) {
    sin2_x = x.times(x);
    x = x.times(d5.plus(sin2_x.times(d16.times(sin2_x).minus(d20))));
  }
  return x;
}
function taylorSeries(Ctor, n, x, y, isHyperbolic) {
  var j, t, u, x2, i = 1, pr = Ctor.precision, k = Math.ceil(pr / LOG_BASE);
  external = false;
  x2 = x.times(x);
  u = new Ctor(y);
  for (; ; ) {
    t = divide(u.times(x2), new Ctor(n++ * n++), pr, 1);
    u = isHyperbolic ? y.plus(t) : y.minus(t);
    y = divide(t.times(x2), new Ctor(n++ * n++), pr, 1);
    t = u.plus(y);
    if (t.d[k] !== void 0) {
      for (j = k; t.d[j] === u.d[j] && j--; ) ;
      if (j == -1) break;
    }
    j = u;
    u = y;
    y = t;
    t = j;
    i++;
  }
  external = true;
  t.d.length = k + 1;
  return t;
}
function tinyPow(b, e) {
  var n = b;
  while (--e) n *= b;
  return n;
}
function toLessThanHalfPi(Ctor, x) {
  var t, isNeg = x.s < 0, pi = getPi(Ctor, Ctor.precision, 1), halfPi = pi.times(0.5);
  x = x.abs();
  if (x.lte(halfPi)) {
    quadrant = isNeg ? 4 : 1;
    return x;
  }
  t = x.divToInt(pi);
  if (t.isZero()) {
    quadrant = isNeg ? 3 : 2;
  } else {
    x = x.minus(t.times(pi));
    if (x.lte(halfPi)) {
      quadrant = isOdd(t) ? isNeg ? 2 : 3 : isNeg ? 4 : 1;
      return x;
    }
    quadrant = isOdd(t) ? isNeg ? 1 : 4 : isNeg ? 3 : 2;
  }
  return x.minus(pi).abs();
}
function toStringBinary(x, baseOut, sd, rm) {
  var base, e, i, k, len, roundUp, str, xd, y, Ctor = x.constructor, isExp = sd !== void 0;
  if (isExp) {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
  } else {
    sd = Ctor.precision;
    rm = Ctor.rounding;
  }
  if (!x.isFinite()) {
    str = nonFiniteToString(x);
  } else {
    str = finiteToString(x);
    i = str.indexOf(".");
    if (isExp) {
      base = 2;
      if (baseOut == 16) {
        sd = sd * 4 - 3;
      } else if (baseOut == 8) {
        sd = sd * 3 - 2;
      }
    } else {
      base = baseOut;
    }
    if (i >= 0) {
      str = str.replace(".", "");
      y = new Ctor(1);
      y.e = str.length - i;
      y.d = convertBase(finiteToString(y), 10, base);
      y.e = y.d.length;
    }
    xd = convertBase(str, 10, base);
    e = len = xd.length;
    for (; xd[--len] == 0; ) xd.pop();
    if (!xd[0]) {
      str = isExp ? "0p+0" : "0";
    } else {
      if (i < 0) {
        e--;
      } else {
        x = new Ctor(x);
        x.d = xd;
        x.e = e;
        x = divide(x, y, sd, rm, 0, base);
        xd = x.d;
        e = x.e;
        roundUp = inexact;
      }
      i = xd[sd];
      k = base / 2;
      roundUp = roundUp || xd[sd + 1] !== void 0;
      roundUp = rm < 4 ? (i !== void 0 || roundUp) && (rm === 0 || rm === (x.s < 0 ? 3 : 2)) : i > k || i === k && (rm === 4 || roundUp || rm === 6 && xd[sd - 1] & 1 || rm === (x.s < 0 ? 8 : 7));
      xd.length = sd;
      if (roundUp) {
        for (; ++xd[--sd] > base - 1; ) {
          xd[sd] = 0;
          if (!sd) {
            ++e;
            xd.unshift(1);
          }
        }
      }
      for (len = xd.length; !xd[len - 1]; --len) ;
      for (i = 0, str = ""; i < len; i++) str += NUMERALS.charAt(xd[i]);
      if (isExp) {
        if (len > 1) {
          if (baseOut == 16 || baseOut == 8) {
            i = baseOut == 16 ? 4 : 3;
            for (--len; len % i; len++) str += "0";
            xd = convertBase(str, base, baseOut);
            for (len = xd.length; !xd[len - 1]; --len) ;
            for (i = 1, str = "1."; i < len; i++) str += NUMERALS.charAt(xd[i]);
          } else {
            str = str.charAt(0) + "." + str.slice(1);
          }
        }
        str = str + (e < 0 ? "p" : "p+") + e;
      } else if (e < 0) {
        for (; ++e; ) str = "0" + str;
        str = "0." + str;
      } else {
        if (++e > len) for (e -= len; e--; ) str += "0";
        else if (e < len) str = str.slice(0, e) + "." + str.slice(e);
      }
    }
    str = (baseOut == 16 ? "0x" : baseOut == 2 ? "0b" : baseOut == 8 ? "0o" : "") + str;
  }
  return x.s < 0 ? "-" + str : str;
}
function truncate(arr, len) {
  if (arr.length > len) {
    arr.length = len;
    return true;
  }
}
function abs(x) {
  return new this(x).abs();
}
function acos(x) {
  return new this(x).acos();
}
function acosh(x) {
  return new this(x).acosh();
}
function add(x, y) {
  return new this(x).plus(y);
}
function asin(x) {
  return new this(x).asin();
}
function asinh(x) {
  return new this(x).asinh();
}
function atan(x) {
  return new this(x).atan();
}
function atanh(x) {
  return new this(x).atanh();
}
function atan2(y, x) {
  y = new this(y);
  x = new this(x);
  var r, pr = this.precision, rm = this.rounding, wpr = pr + 4;
  if (!y.s || !x.s) {
    r = new this(NaN);
  } else if (!y.d && !x.d) {
    r = getPi(this, wpr, 1).times(x.s > 0 ? 0.25 : 0.75);
    r.s = y.s;
  } else if (!x.d || y.isZero()) {
    r = x.s < 0 ? getPi(this, pr, rm) : new this(0);
    r.s = y.s;
  } else if (!y.d || x.isZero()) {
    r = getPi(this, wpr, 1).times(0.5);
    r.s = y.s;
  } else if (x.s < 0) {
    this.precision = wpr;
    this.rounding = 1;
    r = this.atan(divide(y, x, wpr, 1));
    x = getPi(this, wpr, 1);
    this.precision = pr;
    this.rounding = rm;
    r = y.s < 0 ? r.minus(x) : r.plus(x);
  } else {
    r = this.atan(divide(y, x, wpr, 1));
  }
  return r;
}
function cbrt(x) {
  return new this(x).cbrt();
}
function ceil(x) {
  return finalise(x = new this(x), x.e + 1, 2);
}
function clamp(x, min2, max2) {
  return new this(x).clamp(min2, max2);
}
function config(obj) {
  if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
  var i, p, v, useDefaults = obj.defaults === true, ps = [
    "precision",
    1,
    MAX_DIGITS,
    "rounding",
    0,
    8,
    "toExpNeg",
    -EXP_LIMIT,
    0,
    "toExpPos",
    0,
    EXP_LIMIT,
    "maxE",
    0,
    EXP_LIMIT,
    "minE",
    -EXP_LIMIT,
    0,
    "modulo",
    0,
    9
  ];
  for (i = 0; i < ps.length; i += 3) {
    if (p = ps[i], useDefaults) this[p] = DEFAULTS[p];
    if ((v = obj[p]) !== void 0) {
      if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
      else throw Error(invalidArgument + p + ": " + v);
    }
  }
  if (p = "crypto", useDefaults) this[p] = DEFAULTS[p];
  if ((v = obj[p]) !== void 0) {
    if (v === true || v === false || v === 0 || v === 1) {
      if (v) {
        if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
          this[p] = true;
        } else {
          throw Error(cryptoUnavailable);
        }
      } else {
        this[p] = false;
      }
    } else {
      throw Error(invalidArgument + p + ": " + v);
    }
  }
  return this;
}
function cos(x) {
  return new this(x).cos();
}
function cosh(x) {
  return new this(x).cosh();
}
function clone(obj) {
  var i, p, ps;
  function Decimal2(v) {
    var e, i2, t, x = this;
    if (!(x instanceof Decimal2)) return new Decimal2(v);
    x.constructor = Decimal2;
    if (isDecimalInstance(v)) {
      x.s = v.s;
      if (external) {
        if (!v.d || v.e > Decimal2.maxE) {
          x.e = NaN;
          x.d = null;
        } else if (v.e < Decimal2.minE) {
          x.e = 0;
          x.d = [0];
        } else {
          x.e = v.e;
          x.d = v.d.slice();
        }
      } else {
        x.e = v.e;
        x.d = v.d ? v.d.slice() : v.d;
      }
      return;
    }
    t = typeof v;
    if (t === "number") {
      if (v === 0) {
        x.s = 1 / v < 0 ? -1 : 1;
        x.e = 0;
        x.d = [0];
        return;
      }
      if (v < 0) {
        v = -v;
        x.s = -1;
      } else {
        x.s = 1;
      }
      if (v === ~~v && v < 1e7) {
        for (e = 0, i2 = v; i2 >= 10; i2 /= 10) e++;
        if (external) {
          if (e > Decimal2.maxE) {
            x.e = NaN;
            x.d = null;
          } else if (e < Decimal2.minE) {
            x.e = 0;
            x.d = [0];
          } else {
            x.e = e;
            x.d = [v];
          }
        } else {
          x.e = e;
          x.d = [v];
        }
        return;
      }
      if (v * 0 !== 0) {
        if (!v) x.s = NaN;
        x.e = NaN;
        x.d = null;
        return;
      }
      return parseDecimal(x, v.toString());
    }
    if (t === "string") {
      if ((i2 = v.charCodeAt(0)) === 45) {
        v = v.slice(1);
        x.s = -1;
      } else {
        if (i2 === 43) v = v.slice(1);
        x.s = 1;
      }
      return isDecimal.test(v) ? parseDecimal(x, v) : parseOther(x, v);
    }
    if (t === "bigint") {
      if (v < 0) {
        v = -v;
        x.s = -1;
      } else {
        x.s = 1;
      }
      return parseDecimal(x, v.toString());
    }
    throw Error(invalidArgument + v);
  }
  Decimal2.prototype = P;
  Decimal2.ROUND_UP = 0;
  Decimal2.ROUND_DOWN = 1;
  Decimal2.ROUND_CEIL = 2;
  Decimal2.ROUND_FLOOR = 3;
  Decimal2.ROUND_HALF_UP = 4;
  Decimal2.ROUND_HALF_DOWN = 5;
  Decimal2.ROUND_HALF_EVEN = 6;
  Decimal2.ROUND_HALF_CEIL = 7;
  Decimal2.ROUND_HALF_FLOOR = 8;
  Decimal2.EUCLID = 9;
  Decimal2.config = Decimal2.set = config;
  Decimal2.clone = clone;
  Decimal2.isDecimal = isDecimalInstance;
  Decimal2.abs = abs;
  Decimal2.acos = acos;
  Decimal2.acosh = acosh;
  Decimal2.add = add;
  Decimal2.asin = asin;
  Decimal2.asinh = asinh;
  Decimal2.atan = atan;
  Decimal2.atanh = atanh;
  Decimal2.atan2 = atan2;
  Decimal2.cbrt = cbrt;
  Decimal2.ceil = ceil;
  Decimal2.clamp = clamp;
  Decimal2.cos = cos;
  Decimal2.cosh = cosh;
  Decimal2.div = div;
  Decimal2.exp = exp;
  Decimal2.floor = floor;
  Decimal2.hypot = hypot;
  Decimal2.ln = ln;
  Decimal2.log = log;
  Decimal2.log10 = log10;
  Decimal2.log2 = log2;
  Decimal2.max = max;
  Decimal2.min = min;
  Decimal2.mod = mod;
  Decimal2.mul = mul;
  Decimal2.pow = pow;
  Decimal2.random = random;
  Decimal2.round = round;
  Decimal2.sign = sign;
  Decimal2.sin = sin;
  Decimal2.sinh = sinh;
  Decimal2.sqrt = sqrt;
  Decimal2.sub = sub;
  Decimal2.sum = sum;
  Decimal2.tan = tan;
  Decimal2.tanh = tanh;
  Decimal2.trunc = trunc;
  if (obj === void 0) obj = {};
  if (obj) {
    if (obj.defaults !== true) {
      ps = ["precision", "rounding", "toExpNeg", "toExpPos", "maxE", "minE", "modulo", "crypto"];
      for (i = 0; i < ps.length; ) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
    }
  }
  Decimal2.config(obj);
  return Decimal2;
}
function div(x, y) {
  return new this(x).div(y);
}
function exp(x) {
  return new this(x).exp();
}
function floor(x) {
  return finalise(x = new this(x), x.e + 1, 3);
}
function hypot() {
  var i, n, t = new this(0);
  external = false;
  for (i = 0; i < arguments.length; ) {
    n = new this(arguments[i++]);
    if (!n.d) {
      if (n.s) {
        external = true;
        return new this(1 / 0);
      }
      t = n;
    } else if (t.d) {
      t = t.plus(n.times(n));
    }
  }
  external = true;
  return t.sqrt();
}
function isDecimalInstance(obj) {
  return obj instanceof Decimal || obj && obj.toStringTag === tag || false;
}
function ln(x) {
  return new this(x).ln();
}
function log(x, y) {
  return new this(x).log(y);
}
function log2(x) {
  return new this(x).log(2);
}
function log10(x) {
  return new this(x).log(10);
}
function max() {
  return maxOrMin(this, arguments, -1);
}
function min() {
  return maxOrMin(this, arguments, 1);
}
function mod(x, y) {
  return new this(x).mod(y);
}
function mul(x, y) {
  return new this(x).mul(y);
}
function pow(x, y) {
  return new this(x).pow(y);
}
function random(sd) {
  var d, e, k, n, i = 0, r = new this(1), rd = [];
  if (sd === void 0) sd = this.precision;
  else checkInt32(sd, 1, MAX_DIGITS);
  k = Math.ceil(sd / LOG_BASE);
  if (!this.crypto) {
    for (; i < k; ) rd[i++] = Math.random() * 1e7 | 0;
  } else if (crypto.getRandomValues) {
    d = crypto.getRandomValues(new Uint32Array(k));
    for (; i < k; ) {
      n = d[i];
      if (n >= 429e7) {
        d[i] = crypto.getRandomValues(new Uint32Array(1))[0];
      } else {
        rd[i++] = n % 1e7;
      }
    }
  } else if (crypto.randomBytes) {
    d = crypto.randomBytes(k *= 4);
    for (; i < k; ) {
      n = d[i] + (d[i + 1] << 8) + (d[i + 2] << 16) + ((d[i + 3] & 127) << 24);
      if (n >= 214e7) {
        crypto.randomBytes(4).copy(d, i);
      } else {
        rd.push(n % 1e7);
        i += 4;
      }
    }
    i = k / 4;
  } else {
    throw Error(cryptoUnavailable);
  }
  k = rd[--i];
  sd %= LOG_BASE;
  if (k && sd) {
    n = mathpow(10, LOG_BASE - sd);
    rd[i] = (k / n | 0) * n;
  }
  for (; rd[i] === 0; i--) rd.pop();
  if (i < 0) {
    e = 0;
    rd = [0];
  } else {
    e = -1;
    for (; rd[0] === 0; e -= LOG_BASE) rd.shift();
    for (k = 1, n = rd[0]; n >= 10; n /= 10) k++;
    if (k < LOG_BASE) e -= LOG_BASE - k;
  }
  r.e = e;
  r.d = rd;
  return r;
}
function round(x) {
  return finalise(x = new this(x), x.e + 1, this.rounding);
}
function sign(x) {
  x = new this(x);
  return x.d ? x.d[0] ? x.s : 0 * x.s : x.s || NaN;
}
function sin(x) {
  return new this(x).sin();
}
function sinh(x) {
  return new this(x).sinh();
}
function sqrt(x) {
  return new this(x).sqrt();
}
function sub(x, y) {
  return new this(x).sub(y);
}
function sum() {
  var i = 0, args = arguments, x = new this(args[i]);
  external = false;
  for (; x.s && ++i < args.length; ) x = x.plus(args[i]);
  external = true;
  return finalise(x, this.precision, this.rounding);
}
function tan(x) {
  return new this(x).tan();
}
function tanh(x) {
  return new this(x).tanh();
}
function trunc(x) {
  return finalise(x = new this(x), x.e + 1, 1);
}
P[Symbol.for("nodejs.util.inspect.custom")] = P.toString;
P[Symbol.toStringTag] = "Decimal";
var Decimal = P.constructor = clone(DEFAULTS);
LN10 = new Decimal(LN10);
PI = new Decimal(PI);
var decimal_default = Decimal;

// packages/contracts/src/quantity.ts
decimal_default.set({ precision: 36, rounding: decimal_default.ROUND_HALF_UP });
function quantityError(value, unit) {
  if (!/^[0-9]{1,15}(\.[0-9]{1,3})?$/.test(value)) {
    return "\u8BF7\u8F93\u5165\u6B63\u6570\uFF0C\u516C\u65A4\u6700\u591A\u4FDD\u7559\u4E09\u4F4D\u5C0F\u6570";
  }
  const quantity = new decimal_default(value);
  if (quantity.lessThanOrEqualTo(0)) {
    return "\u672C\u6B21\u6570\u91CF\u8981\u5927\u4E8E\u96F6";
  }
  if (unit !== "\u516C\u65A4" && !quantity.isInteger()) {
    return `${unit || "\u5305\u88C5"}\u6570\u91CF\u5FC5\u987B\u662F\u6574\u6570`;
  }
  return null;
}
function addQuantities(left, right) {
  return new decimal_default(left || "0").plus(right || "0").toFixed();
}
function subtractQuantities(left, right) {
  return new decimal_default(left || "0").minus(right || "0").toFixed();
}
function compareQuantities(left, right) {
  return new decimal_default(left || "0").comparedTo(right || "0");
}

// packages/contracts/src/errors.ts
var ApiError = class extends Error {
  constructor(status, failure) {
    super(failure.message);
    this.status = status;
    this.failure = failure;
    this.name = "ApiError";
  }
};
function isApiFailure(value) {
  return typeof value === "object" && value !== null && "code" in value && typeof value.code === "string" && "message" in value && typeof value.message === "string";
}
function friendlyError(error) {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      if (["INVALID_CREDENTIALS", "ACCOUNT_DISABLED"].includes(error.failure.code)) {
        return error.message;
      }
      return "\u767B\u5F55\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDB\u5165\uFF1B\u672A\u63D0\u4EA4\u7684\u5185\u5BB9\u8FD8\u5728";
    }
    if (error.failure.code === "CSRF_REJECTED") {
      return "\u9875\u9762\u9A8C\u8BC1\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55\u540E\u64CD\u4F5C";
    }
    if (error.status === 403) {
      return error.message || "\u8FD9\u4E2A\u64CD\u4F5C\u9700\u8981\u7BA1\u7406\u5458\u534F\u52A9";
    }
    if (error.status >= 500 || error.status === 0) {
      return "\u6682\u65F6\u6CA1\u6709\u786E\u8BA4\u7ED3\u679C\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u67E5\u8BE2\u539F\u63D0\u4EA4\u7ED3\u679C";
    }
    return error.message;
  }
  return error instanceof Error ? error.message : "\u6682\u65F6\u65E0\u6CD5\u5B8C\u6210\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5";
}

// packages/contracts/src/validation.ts
function validateDocument(document, resource, archives, posting = true) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
  const errors = [];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(document.businessDate)) {
    errors.push("\u8BF7\u9009\u62E9\u4E1A\u52A1\u65E5\u671F");
  }
  if (resource === "work-records" && (!document.items.length || !((_a = document.vegetables) == null ? void 0 : _a.length))) {
    errors.push("\u88C5\u83DC\u767B\u8BB0\u9700\u8981\u586B\u5199\u5305\u88C5\u6D88\u8017\u548C\u852C\u83DC\u4EA7\u51FA");
  }
  if (resource === "outbounds" && !["NORMAL", "DIRECT"].includes((_b = document.mode) != null ? _b : "")) {
    errors.push("\u8BF7\u9009\u62E9\u6B63\u5E38\u51FA\u5E93\u6216\u624B\u5DE5\u51FA\u5E93");
  }
  if (resource === "stock-documents" && !["OPENING", "REPLENISHMENT", "EXTERNAL", "ADJUSTMENT"].includes((_c = document.source) != null ? _c : "")) {
    errors.push("\u8BF7\u9009\u62E9\u5E93\u5B58\u6765\u6E90");
  }
  if (((_e = (_d = document.lossReason) == null ? void 0 : _d.length) != null ? _e : 0) > 500 || ((_g = (_f = document.differenceReason) == null ? void 0 : _f.length) != null ? _g : 0) > 500) {
    errors.push("\u539F\u56E0\u6700\u591A500\u5B57");
  }
  if (((_i = (_h = document.remark) == null ? void 0 : _h.length) != null ? _i : 0) > 500) {
    errors.push("\u5907\u6CE8\u6700\u591A500\u5B57");
  }
  const lines = [...document.items, ...(_j = document.vegetables) != null ? _j : []];
  if (lines.length === 0 && !(resource === "recoveries" && document.mode === "FINAL")) {
    errors.push("\u8BF7\u586B\u5199\u672C\u6B21\u7684\u54C1\u7C7B\u548C\u6570\u91CF");
  }
  if (document.items.length > 200 || ((_l = (_k = document.vegetables) == null ? void 0 : _k.length) != null ? _l : 0) > 200) {
    errors.push("\u6BCF\u7EC4\u6700\u591A\u586B\u5199200\u884C");
  }
  for (const line of lines) {
    const archive = archives.find((item) => item.id === line.itemId);
    if (!archive || !archive.enabled) {
      errors.push("\u8BF7\u9009\u62E9\u6709\u6548\u4E14\u542F\u7528\u7684\u54C1\u7C7B");
      continue;
    }
    const error = quantityError(line.quantity, archive.unit);
    if (error) {
      errors.push(`${archive.name}\uFF1A${error}`);
    }
    if (resource === "dispatches" && !line.growerId) {
      errors.push("\u6BCF\u79CD\u5305\u88C5\u90FD\u8981\u9009\u5B9A\u68DA\u6237");
    }
  }
  if ((resource === "work-records" || resource === "recoveries") && !document.batchId) {
    errors.push("\u8BF7\u9009\u62E9\u68DA\u6237\u4F5C\u4E1A\u6279\u6B21");
  }
  if (resource === "recoveries" && !["PARTIAL", "FINAL"].includes((_m = document.mode) != null ? _m : "")) {
    errors.push("\u8BF7\u9009\u62E9\u8FD9\u6237\u8FD8\u6CA1\u6536\u5B8C\uFF0C\u6216\u8FD9\u6237\u5DF2\u7ECF\u6536\u5B8C");
  }
  if (resource === "recoveries" && document.mode === "FINAL" && posting && !document.confirmFinal) {
    errors.push("\u8BF7\u786E\u8BA4\u672C\u6B21\u7ED3\u675F\u8FD9\u4E2A\u68DA\u6237\u4EFB\u52A1");
  }
  if (resource === "outbounds" && !document.customerId) {
    errors.push("\u8BF7\u9009\u62E9\u5BA2\u6237");
  }
  if (resource === "outbounds" && document.mode === "DIRECT" && !((_n = document.remark) == null ? void 0 : _n.trim())) {
    errors.push("\u8BF7\u8BF4\u660E\u624B\u5DE5\u51FA\u5E93\u7684\u852C\u83DC\u6765\u6E90");
  }
  if (resource === "stock-documents" && document.source === "ADJUSTMENT" && !((_o = document.remark) == null ? void 0 : _o.trim())) {
    errors.push("\u8BF7\u586B\u5199\u5E93\u5B58\u8C03\u6574\u539F\u56E0");
  }
  return [...new Set(errors)];
}

// packages/contracts/src/submission.ts
function newSubmissionKey() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}
function makeTicket(operation, path, body) {
  return {
    key: newSubmissionKey(),
    operation,
    path,
    body: JSON.parse(JSON.stringify(body))
  };
}
async function confirmSubmission(client, ticket) {
  var _a;
  try {
    const result = await client.request("POST", ticket.path, ticket.body, {
      "Idempotency-Key": ticket.key
    });
    return { state: "succeeded", result };
  } catch (error) {
    if (error instanceof ApiError && error.status > 0 && error.status < 500) {
      throw error;
    }
    try {
      const status = await client.request(
        "GET",
        `/api/submissions/status?operation=${encodeURIComponent(ticket.operation)}&key=${encodeURIComponent(ticket.key)}`
      );
      if (status.status === "SUCCEEDED" && status.result) {
        return { state: "succeeded", result: status.result };
      }
      if (status.status === "FAILED") {
        throw new ApiError(409, {
          code: (_a = status.failureCode) != null ? _a : "SUBMISSION_FAILED",
          message: "\u8FD9\u6B21\u5C1A\u672A\u8BB0\u8D26\uFF0C\u8BF7\u68C0\u67E5\u8F93\u5165\u540E\u7528\u539F\u6807\u8BC6\u518D\u8BD5"
        });
      }
    } catch (queryError) {
      if (queryError instanceof ApiError && queryError.status > 0 && queryError.status < 500) {
        throw queryError;
      }
    }
    return {
      state: "pending",
      message: "\u6682\u65F6\u6CA1\u67E5\u5230\u7ED3\u679C\u3002\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u7528\u201C\u786E\u8BA4\u539F\u63D0\u4EA4\u7ED3\u679C\u201D\u7EE7\u7EED\uFF0C\u4E0D\u8981\u65B0\u5EFA\u4E00\u7B14\u3002"
    };
  }
}

// apps/miniprogram/src/services/api.ts
var import_settings = require("../../config/runtime.js");

// apps/miniprogram/src/types.ts
function appState() {
  return getApp();
}

// apps/miniprogram/src/services/api.ts
var api = {
  async request(method, path, body, extraHeaders = {}) {
    var _a;
    const headers = { "Content-Type": "application/json", ...extraHeaders };
    const token = (_a = appState().globalData.session) == null ? void 0 : _a.token;
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    let status;
    let raw;
    try {
      if (import_settings.settings.mode === "cloud") {
        if (!import_settings.settings.envId || !import_settings.settings.serviceName) {
          throw new Error("\u8BF7\u7BA1\u7406\u5458\u5148\u914D\u7F6E\u5C0F\u7A0B\u5E8F\u7684\u4E91\u6258\u7BA1\u73AF\u5883\u548C\u670D\u52A1\u540D\u79F0");
        }
        const response = await wx.cloud.callContainer({
          config: { env: import_settings.settings.envId },
          path,
          method,
          header: { ...headers, "X-WX-SERVICE": import_settings.settings.serviceName },
          data: body === void 0 ? void 0 : JSON.stringify(body)
        });
        status = response.statusCode;
        raw = response.data;
      } else {
        const response = await new Promise(
          (resolve, reject) => {
            wx.request({
              url: import_settings.settings.apiBaseUrl.replace(/\/$/, "") + path,
              method,
              header: headers,
              data: body === void 0 ? void 0 : JSON.stringify(body),
              timeout: 3e4,
              success: resolve,
              fail: () => reject(
                new ApiError(0, { code: "NETWORK_ERROR", message: "\u7F51\u7EDC\u6CA1\u6709\u8FDE\u4E0A\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" })
              )
            });
          }
        );
        status = response.statusCode;
        raw = response.data;
      }
    } catch (failure) {
      if (failure instanceof ApiError || failure instanceof Error && failure.message.startsWith("\u8BF7\u7BA1\u7406\u5458")) {
        throw failure;
      }
      throw new ApiError(0, { code: "NETWORK_ERROR", message: "\u7F51\u7EDC\u6CA1\u6709\u8FDE\u4E0A\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5" });
    }
    let data;
    try {
      data = typeof raw === "string" && raw ? JSON.parse(raw) : raw;
    } catch (e) {
      throw new ApiError(502, {
        code: "INVALID_RESPONSE",
        message: "\u6682\u65F6\u6CA1\u6709\u786E\u8BA4\u7ED3\u679C\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u67E5\u8BE2\u539F\u63D0\u4EA4"
      });
    }
    if (status < 200 || status >= 300) {
      throw new ApiError(
        status,
        isApiFailure(data) ? data : { code: "REQUEST_FAILED", message: "\u6682\u65F6\u6CA1\u80FD\u5B8C\u6210\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" }
      );
    }
    return data;
  }
};
async function allPages(path, filter = {}) {
  const items = [];
  for (let page = 1; page <= 500; page += 1) {
    const response = await api.request(
      "GET",
      `${path}?${queryString({ ...filter, page, pageSize: 100 })}`
    );
    items.push(...response.items);
    if (response.items.length < 100) {
      return items;
    }
  }
  throw new Error("\u8BB0\u5F55\u8F83\u591A\uFF0C\u8BF7\u6309\u68DA\u6237\u59D3\u540D\u7F29\u5C0F\u67E5\u8BE2\u8303\u56F4");
}

// apps/miniprogram/src/services/drafts.ts
function key(ownerId, resource, editingId) {
  return `warehouse:draft:${ownerId}:${resource}:${editingId != null ? editingId : "new"}`;
}
function saveDraft(draft) {
  wx.setStorageSync(key(draft.ownerId, draft.resource, draft.editingId), draft);
}
function getDraft(ownerId, resource, editingId) {
  const value = wx.getStorageSync(key(ownerId, resource, editingId));
  if (typeof value !== "object" || value === null || !("ownerId" in value) || value.ownerId !== ownerId || !("resource" in value) || value.resource !== resource || !("document" in value)) {
    return null;
  }
  return value;
}
function removeDraft(ownerId, resource, editingId) {
  wx.removeStorageSync(key(ownerId, resource, editingId));
}
async function offerDraft(ownerId, resource, editingId, targetBatchId) {
  const draft = getDraft(ownerId, resource, editingId);
  if (!draft) {
    return null;
  }
  const choice = await new Promise((resolve) => {
    wx.showModal({
      title: draft.ticket ? "\u4E0A\u4E00\u7B14\u8FD8\u5728\u786E\u8BA4\u7ED3\u679C" : "\u4E0A\u6B21\u8FD8\u6CA1\u63D0\u4EA4",
      content: draft.ticket ? "\u4FDD\u7559\u539F\u63D0\u4EA4\u6807\u8BC6\uFF0C\u7EE7\u7EED\u786E\u8BA4\u662F\u5426\u5DF2\u8BB0\u597D\uFF0C\u907F\u514D\u91CD\u590D\u8BB0\u8D26\u3002" : targetBatchId && draft.document.batchId !== targetBatchId ? "\u60A8\u521A\u9009\u4E86\u53E6\u4E00\u6237\u4EFB\u52A1\u3002\u7EE7\u7EED\u586B\u5199\u4F1A\u8FD4\u56DE\u4E0A\u6B21\u8349\u7A3F\uFF1B\u91CD\u65B0\u586B\u5199\u4F1A\u4F7F\u7528\u521A\u9009\u7684\u68DA\u6237\uFF0C\u8BF7\u6838\u5BF9\u9876\u90E8\u59D3\u540D\u3002" : "\u7EE7\u7EED\u586B\u5199\u4E0A\u6B21\u4FDD\u5B58\u7684\u5185\u5BB9\u5417\uFF1F\u4F1A\u91CD\u65B0\u68C0\u67E5\u5F53\u524D\u8D26\u53F7\u3001\u68DA\u6237\u4E0E\u53EF\u7528\u5305\u88C5\u3002",
      confirmText: "\u7EE7\u7EED\u586B\u5199",
      cancelText: draft.ticket ? "\u7A0D\u540E\u5904\u7406" : "\u91CD\u65B0\u586B\u5199",
      success: resolve
    });
  });
  if (choice.confirm) {
    return draft;
  }
  if (!draft.ticket) {
    removeDraft(ownerId, resource, editingId);
  } else {
    wx.navigateBack();
  }
  return null;
}

// apps/miniprogram/src/services/forms.ts
async function submitDocument(ownerId, resource, document, existingTicket, editingId, version) {
  let ticket = existingTicket;
  if (!ticket) {
    if (editingId) {
      const updated = await api.request(
        "PUT",
        `/api/${resource}/${editingId}?version=${version}`,
        document
      );
      ticket = makeTicket(
        `${resourceKinds[resource]}:${editingId}:post`,
        `/api/${resource}/${editingId}/post`,
        { version: updated.version }
      );
    } else {
      ticket = makeTicket(`${resourceKinds[resource]}:create`, `/api/${resource}`, {
        post: true,
        document
      });
    }
  }
  saveDraft({
    ownerId,
    resource,
    document,
    editingId,
    version,
    ticket,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  const outcome = await confirmSubmission(api, ticket);
  if (outcome.state === "succeeded") {
    removeDraft(ownerId, resource, editingId);
    return { ticket, result: outcome.result, pending: false };
  }
  return { ticket, pending: true };
}
function rememberForm(ownerId, resource, document, editingId, version, ticket) {
  saveDraft({
    ownerId,
    resource,
    document,
    editingId,
    version,
    ticket,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  wx.enableAlertBeforeUnload({ message: "\u8FD8\u6CA1\u8BB0\u8D26\uFF0C\u5185\u5BB9\u5DF2\u4FDD\u5B58\u8349\u7A3F\u3002\u8981\u79BB\u5F00\u5417\uFF1F" });
}
function showSubmitted(resource, result) {
  wx.disableAlertBeforeUnload();
  wx.redirectTo({ url: `/pages/detail/index?resource=${resource}&id=${result.id}&success=1` });
}

// apps/miniprogram/src/services/session.ts
var import_settings2 = require("../../config/runtime.js");
function clearDrafts() {
  for (const key2 of wx.getStorageInfoSync().keys) {
    if (key2.startsWith("warehouse:draft:")) {
      wx.removeStorageSync(key2);
    }
  }
}
function saveSession(session) {
  var _a, _b;
  const previousOwner = (_b = (_a = appState().globalData.session) == null ? void 0 : _a.userId) != null ? _b : Number(wx.getStorageSync("warehouse:owner") || 0);
  if (previousOwner && previousOwner !== session.userId) {
    clearDrafts();
  }
  appState().globalData.session = session;
  appState().globalData.bindingToken = "";
  wx.setStorageSync("warehouse:session", session);
  wx.setStorageSync("warehouse:owner", session.userId);
}
async function startWechatLogin() {
  const login = await new Promise(
    (resolve, reject) => {
      wx.login({
        success: resolve,
        fail: () => reject(new Error("\u5FAE\u4FE1\u6682\u65F6\u6CA1\u80FD\u786E\u8BA4\u8EAB\u4EFD\uFF0C\u8BF7\u70B9\u201C\u91CD\u65B0\u8FDB\u5165\u201D"))
      });
    }
  );
  const result = await api.request(
    "POST",
    "/api/auth/wechat-login",
    { code: login.code }
  );
  if ("token" in result) {
    saveSession(result);
  } else {
    appState().globalData.session = null;
    wx.removeStorageSync("warehouse:session");
    appState().globalData.bindingToken = result.bindingToken;
  }
  return result;
}
async function requireSession() {
  const session = appState().globalData.session;
  if (session) {
    try {
      const identity = await api.request("GET", "/api/auth/me");
      const refreshed = {
        ...session,
        name: identity.name,
        roles: identity.roles,
        selectedRole: identity.selectedRole
      };
      saveSession(refreshed);
      return refreshed;
    } catch (failure) {
      if (!(failure instanceof ApiError) || failure.status !== 401) {
        throw failure;
      }
      appState().globalData.session = null;
      wx.removeStorageSync("warehouse:session");
      if (import_settings2.settings.mode === "local") {
        wx.reLaunch({ url: "/pages/start/index" });
        return null;
      }
    }
  }
  if (import_settings2.settings.mode === "cloud") {
    const result = await startWechatLogin();
    if ("token" in result) {
      return result;
    }
  }
  wx.reLaunch({ url: "/pages/start/index" });
  return null;
}

// apps/miniprogram/src/services/document-page.ts
var emptyLine = (options) => ({
  itemId: options.length === 1 ? options[0].id : 0,
  quantity: ""
});
var cleanLines = (lines) => lines.filter((line) => line.quantity.trim() !== "");
function lineTotal(lines, itemId) {
  return lines.filter((line) => line.itemId === itemId).reduce((sum2, line) => addQuantities(sum2, line.quantity || "0"), "0");
}
function rawInput(host) {
  const value = host.data.document;
  return {
    ...value,
    items: host.data.resource === "dispatches" ? host.data.groups.flatMap(
      (group) => group.lines.map((line) => ({ ...line, growerId: group.growerId }))
    ) : value.items
  };
}
function inputFor(host) {
  var _a;
  const value = rawInput(host);
  return {
    ...value,
    items: cleanLines(value.items),
    vegetables: cleanLines((_a = value.vegetables) != null ? _a : [])
  };
}
function save(host) {
  if (host.data.ownerId && !host.data.locked && !host.data.confirming) {
    rememberForm(
      host.data.ownerId,
      host.data.resource,
      rawInput(host),
      host.data.editingId || void 0,
      host.data.version || void 0
    );
  }
}
function reconstructGroups(document, growers) {
  var _a, _b, _c, _d;
  const groups = /* @__PURE__ */ new Map();
  for (const line of document.items) {
    const growerId = (_a = line.growerId) != null ? _a : 0;
    const group = (_d = groups.get(growerId)) != null ? _d : {
      key: growerId,
      growerId,
      growerName: (_c = (_b = growers.find((item) => item.id === growerId)) == null ? void 0 : _b.name) != null ? _c : "\u8BF7\u9009\u62E9\u68DA\u6237",
      lines: []
    };
    group.lines.push(line);
    groups.set(growerId, group);
  }
  return [...groups.values()];
}
async function refreshContext(host) {
  var _a, _b;
  const resource = host.data.resource;
  const paths = resource === "dispatches" ? ["growers", "packaging-types"] : resource === "outbounds" ? ["customers", "vegetable-types"] : ["packaging-types", "vegetable-types"];
  const groups = await Promise.all(paths.map((path) => allPages(`/api/${path}`)));
  const archives = groups.flat().filter((item) => item.enabled);
  const packaging = archives.filter((item) => item.kind === "PACKAGING");
  host.setData({
    archives,
    growers: archives.filter((item) => item.kind === "GROWER"),
    customers: archives.filter((item) => item.kind === "CUSTOMER"),
    packaging,
    vegetables: archives.filter((item) => item.kind === "VEGETABLE")
  });
  if (host.data.document.batchId) {
    const batch = await api.request(
      "GET",
      `/api/batches/${host.data.document.batchId}/summary`
    );
    const options = packaging.filter(
      (item) => batch.packaging.some((balance) => balance.itemId === item.id)
    );
    host.setData({
      batch,
      batchLabel: `${batch.batch.growerName} \xB7 ${batch.batch.businessDate.slice(0, 10)} \xB7 \u53F8\u673A${batch.batch.driverName}`,
      packaging: options
    });
  }
  if ((resource === "work-records" || resource === "recoveries") && !host.data.document.batchId) {
    host.setData({ packaging: [] });
  }
  if (resource === "outbounds") {
    host.setData({
      inventory: await allPages("/api/inventory/vegetables"),
      customerName: (_b = (_a = host.data.customers.find((item) => item.id === host.data.document.customerId)) == null ? void 0 : _a.name) != null ? _b : ""
    });
  }
}
function summary(host, document) {
  var _a;
  const rows = [{ key: "date", label: "\u4E1A\u52A1\u65E5\u671F", value: document.businessDate }];
  if (host.data.batch) {
    rows.push({ key: "batch", label: "\u672C\u6B21\u68DA\u6237", value: host.data.batchLabel });
  }
  if (document.customerId) {
    rows.push({ key: "customer", label: "\u5BA2\u6237", value: host.data.customerName });
  }
  [...document.items, ...(_a = document.vegetables) != null ? _a : []].forEach((line, index) => {
    var _a2, _b;
    const archive = host.data.archives.find((item) => item.id === line.itemId);
    const grower = host.data.growers.find((item) => item.id === line.growerId);
    rows.push({
      key: `line-${index}`,
      label: `${grower ? `${grower.name} \xB7 ` : ""}${(_a2 = archive == null ? void 0 : archive.name) != null ? _a2 : "\u54C1\u7C7B\u5DF2\u505C\u7528"}`,
      value: `${line.quantity} ${(_b = archive == null ? void 0 : archive.unit) != null ? _b : ""}`
    });
  });
  if (host.data.resource === "recoveries") {
    rows.push({
      key: "mode",
      label: "\u672C\u6B21\u56DE\u6536",
      value: document.mode === "FINAL" ? "\u8FD9\u6237\u5DF2\u7ECF\u6536\u5B8C\uFF0C\u672C\u6B21\u7ED3\u675F\u4EFB\u52A1" : "\u8FD9\u6237\u8FD8\u6CA1\u6536\u5B8C\uFF0C\u4EFB\u52A1\u7EE7\u7EED\u4FDD\u7559"
    });
  }
  if (host.data.resource === "outbounds") {
    rows.push({
      key: "mode",
      label: "\u51FA\u5E93\u65B9\u5F0F",
      value: document.mode === "DIRECT" ? "\u624B\u5DE5\u51FA\u5E93\uFF1A\u5B9E\u9645\u6263\u5E93\u5B58\uFF0C\u62A5\u8868\u663E\u793A\u8D1F\u6570" : "\u6B63\u5E38\u51FA\u5E93"
    });
  }
  if (document.remark) {
    rows.push({ key: "remark", label: "\u5907\u6CE8", value: document.remark });
  }
  if (document.lossReason) {
    rows.push({ key: "lossReason", label: "\u5305\u88C5\u635F\u8017\u539F\u56E0", value: document.lossReason });
  }
  if (document.differenceReason) {
    rows.push({ key: "differenceReason", label: "\u852C\u83DC\u5DEE\u5F02\u539F\u56E0", value: document.differenceReason });
  }
  return rows;
}
function recoveryPreview(batch, document) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
  const lossRows = [];
  const differenceRows = [];
  const errors = [];
  for (const balance of batch.packaging) {
    const returned = lineTotal(document.items, balance.itemId);
    const loss = subtractQuantities(balance.outstanding, returned);
    if (compareQuantities(loss, "0") < 0) {
      errors.push(`${balance.name}\u7684\u56DE\u6536\u91CF\u8D85\u8FC7\u5F53\u524D\u5728\u5916\u91CF`);
    }
    if (document.mode === "FINAL") {
      lossRows.push({
        key: `loss-${balance.itemId}`,
        label: `${balance.name}\uFF1A\u6D3E\u53D1${(_a = balance.dispatched) != null ? _a : "0"} \u2212 \u6D88\u8017${(_b = balance.consumed) != null ? _b : "0"} \u2212 \u5DF2\u56DE\u6536${(_c = balance.recovered) != null ? _c : "0"} \u2212 \u672C\u6B21${returned}`,
        value: `\u672C\u6B21\u635F\u8017 ${loss} ${balance.unit}`
      });
      if (compareQuantities(loss, "0") > 0 && !((_d = document.lossReason) == null ? void 0 : _d.trim())) {
        errors.push("\u6709\u5305\u88C5\u635F\u8017\uFF0C\u8BF7\u9009\u62E9\u6216\u586B\u5199\u539F\u56E0");
      }
    }
  }
  const vegetableIds = /* @__PURE__ */ new Set([
    ...batch.vegetables.map((item) => item.itemId),
    ...((_e = document.vegetables) != null ? _e : []).map((line) => line.itemId)
  ]);
  for (const itemId of vegetableIds) {
    const balance = batch.vegetables.find((item) => item.itemId === itemId);
    const now = lineTotal((_f = document.vegetables) != null ? _f : [], itemId);
    const difference = subtractQuantities(
      (_g = balance == null ? void 0 : balance.output) != null ? _g : "0",
      addQuantities((_h = balance == null ? void 0 : balance.received) != null ? _h : "0", now)
    );
    if ((document.mode === "FINAL" || compareQuantities(difference, "0") < 0) && compareQuantities(difference, "0") !== 0) {
      differenceRows.push({
        key: `difference-${itemId}`,
        label: `${(_i = balance == null ? void 0 : balance.name) != null ? _i : "\u672C\u6B21\u852C\u83DC"}\uFF1A\u88C5\u83DC${(_j = balance == null ? void 0 : balance.output) != null ? _j : "0"} \u2212 \u5DF2\u6536${(_k = balance == null ? void 0 : balance.received) != null ? _k : "0"} \u2212 \u672C\u6B21${now}`,
        value: `\u5DEE\u5F02 ${difference} ${(_l = balance == null ? void 0 : balance.unit) != null ? _l : ""}`
      });
      if (!((_m = document.differenceReason) == null ? void 0 : _m.trim())) {
        errors.push("\u88C5\u83DC\u4EA7\u51FA\u4E0E\u53F8\u673A\u5B9E\u6536\u6709\u5DEE\u5F02\uFF0C\u8BF7\u586B\u5199\u539F\u56E0");
      }
    }
  }
  return { lossRows, differenceRows, errors: [...new Set(errors)] };
}
function createDocumentPage(resource, role) {
  var _a;
  const titles = {
    dispatches: "\u6D3E\u53D1\u5305\u88C5",
    "work-records": "\u88C5\u83DC\u767B\u8BB0",
    recoveries: "\u56DE\u6536\u767B\u8BB0",
    outbounds: "\u51FA\u5E93\u767B\u8BB0"
  };
  const data = {
    resource,
    role,
    ownerId: 0,
    editingId: 0,
    version: 0,
    document: {
      businessDate: businessDateNow(),
      items: [],
      vegetables: [],
      mode: resource === "recoveries" ? "" : "NORMAL",
      remark: "",
      lossReason: "",
      differenceReason: ""
    },
    archives: [],
    growers: [],
    customers: [],
    packaging: [],
    vegetables: [],
    groups: [],
    batch: null,
    batchLabel: "",
    customerName: "",
    inventory: [],
    loading: true,
    saving: false,
    locked: false,
    pending: false,
    confirming: false,
    error: "",
    notice: "",
    summary: [],
    lossRows: [],
    differenceRows: [],
    stepTitle: (_a = titles[resource]) != null ? _a : "",
    lossChoice: "",
    showRemark: false
  };
  return {
    data,
    async onLoad(query) {
      var _a2, _b, _c, _d;
      try {
        const session = await requireSession();
        if (!session) {
          return;
        }
        if (!session.roles.includes(role) || session.selectedRole !== role) {
          throw new Error(`\u8BF7\u5148\u5728\u201C\u6211\u7684\u201D\u4E2D\u9009\u62E9${roleLabels[role]}\u8EAB\u4EFD`);
        }
        const editingId = query.id ? Number(query.id) : 0;
        this.setData({ ownerId: session.userId, editingId });
        let document = {
          ...this.data.document,
          mode: resource === "outbounds" && query.mode === "DIRECT" ? "DIRECT" : this.data.document.mode,
          batchId: query.batchId ? Number(query.batchId) : void 0
        };
        if (editingId) {
          const detail = await api.request("GET", `/api/${resource}/${editingId}`);
          if (detail.document.status !== "DRAFT") {
            throw new Error("\u8FD9\u6761\u8BB0\u5F55\u5DF2\u7ECF\u8BB0\u597D\uFF0C\u4E0D\u80FD\u5728\u5458\u5DE5\u9875\u9762\u4FEE\u6539");
          }
          document = detail.document.input;
          this.setData({ version: detail.document.version });
        }
        const draft = await offerDraft(
          session.userId,
          resource,
          editingId || void 0,
          (_a2 = document.batchId) != null ? _a2 : void 0
        );
        if (!draft && ((_b = getDraft(session.userId, resource, editingId || void 0)) == null ? void 0 : _b.ticket)) {
          this.setData({
            locked: true,
            pending: true,
            notice: "\u8FD9\u7B14\u4ECD\u5728\u786E\u8BA4\u7ED3\u679C\uFF0C\u8BF7\u8FD4\u56DE\u540E\u7EE7\u7EED\u5904\u7406\u539F\u63D0\u4EA4\u3002"
          });
          return;
        }
        if (draft) {
          if (editingId && draft.version !== this.data.version && !draft.ticket) {
            throw new Error("\u8FD9\u4EFD\u8349\u7A3F\u5DF2\u5728\u522B\u5904\u4FEE\u6539\uFF0C\u8BF7\u8FD4\u56DE\u8BB0\u5F55\u8BE6\u60C5\u91CD\u65B0\u6253\u5F00");
          }
          document = draft.document;
          this.setData({
            pending: Boolean(draft.ticket),
            locked: Boolean(draft.ticket),
            notice: draft.ticket ? "\u4E0A\u6B21\u5C1A\u672A\u786E\u8BA4\u7ED3\u679C\uFF0C\u8BF7\u70B9\u201C\u7EE7\u7EED\u786E\u8BA4\u539F\u63D0\u4EA4\u201D\u3002" : "\u5DF2\u6062\u590D\u8349\u7A3F\uFF0C\u5C1A\u672A\u8BB0\u8D26\u3002\u8BF7\u6838\u5BF9\u4E0B\u65B9\u5185\u5BB9\u3002"
          });
        }
        this.setData({ document });
        await refreshContext(this);
        if ((resource === "work-records" || resource === "recoveries") && !document.batchId) {
          const available = (await allPages("/api/batches")).filter(
            (batch) => batch.status === "OPEN"
          );
          if (available.length === 1) {
            document = { ...document, batchId: available[0].id };
            this.setData({ document });
            await refreshContext(this);
            this.setData({
              notice: `\u5F53\u524D\u53EA\u6709\u4E00\u4E2A\u672A\u7ED3\u675F\u4EFB\u52A1\uFF0C\u5DF2\u9009\u4E2D${available[0].growerName}\uFF0C\u8BF7\u6838\u5BF9\u3002`
            });
          }
        }
        if (resource === "dispatches") {
          const groups = reconstructGroups(document, this.data.growers);
          this.setData({
            groups: groups.length ? groups : [
              {
                key: Date.now(),
                growerId: 0,
                growerName: "\u8BF7\u9009\u62E9\u68DA\u6237",
                lines: [emptyLine(this.data.packaging)]
              }
            ]
          });
        } else if (!document.items.length && resource !== "recoveries") {
          this.setData({
            document: {
              ...document,
              items: [
                emptyLine(resource === "outbounds" ? this.data.vegetables : this.data.packaging)
              ]
            }
          });
        }
        if (resource === "work-records" && !((_c = document.vegetables) == null ? void 0 : _c.length)) {
          this.setData({
            document: { ...this.data.document, vegetables: [emptyLine(this.data.vegetables)] }
          });
        }
        if (resource === "recoveries" && !document.items.length) {
          this.setData({
            document: {
              ...this.data.document,
              items: this.data.packaging.map((item) => ({ itemId: item.id, quantity: "" }))
            }
          });
        }
        if (((_d = this.data.batch) == null ? void 0 : _d.batch.status) !== "OPEN" && this.data.batch && !this.data.pending) {
          this.setData({ locked: true, error: "\u8FD9\u6237\u4EFB\u52A1\u5DF2\u7ECF\u7ED3\u675F\u3002\u8BF7\u8FD4\u56DE\u9009\u62E9\u4ECD\u5728\u8FDB\u884C\u7684\u4EFB\u52A1\u3002" });
        }
      } catch (failure) {
        this.setData({ error: friendlyError(failure), locked: true });
      } finally {
        this.setData({ loading: false });
      }
    },
    field(event) {
      if (this.data.locked) {
        return;
      }
      const field = event.currentTarget.dataset.field;
      if (typeof field !== "string") {
        return;
      }
      this.setData({
        document: { ...this.data.document, [field]: event.detail.value },
        confirming: false,
        error: ""
      });
      save(this);
    },
    toggleRemark() {
      this.setData({ showRemark: !this.data.showRemark });
    },
    chooseGrower(event) {
      if (this.data.locked) {
        return;
      }
      const index = Number(event.currentTarget.dataset.group);
      const grower = this.data.growers[Number(event.detail.value)];
      if (!grower) {
        return;
      }
      const groups = this.data.groups.map(
        (group, current) => current === index ? { ...group, growerId: grower.id, growerName: grower.name } : group
      );
      this.setData({ groups, confirming: false });
      save(this);
    },
    chooseCustomer(event) {
      if (this.data.locked) {
        return;
      }
      const customer = this.data.customers[Number(event.detail.value)];
      if (!customer) {
        return;
      }
      this.setData({
        document: { ...this.data.document, customerId: customer.id },
        customerName: customer.name,
        confirming: false
      });
      save(this);
    },
    chooseBatch() {
      if (this.data.locked) {
        return;
      }
      const open = () => {
        removeDraft(this.data.ownerId, resource, this.data.editingId || void 0);
        wx.disableAlertBeforeUnload();
        wx.navigateTo({
          url: `/pages/batches/index?for=${resource === "work-records" ? "work" : "recovery"}`
        });
      };
      if (this.data.document.batchId || this.data.document.items.some((line) => line.quantity)) {
        wx.showModal({
          title: "\u66F4\u6362\u68DA\u6237\u4EFB\u52A1\uFF1F",
          content: "\u4F1A\u6E05\u7A7A\u672C\u6B21\u586B\u5199\u7684\u6570\u91CF\uFF0C\u8BF7\u9009\u62E9\u65B0\u4EFB\u52A1\u540E\u91CD\u65B0\u586B\u5199\u3002",
          success: (choice) => {
            if (choice.confirm) {
              open();
            }
          }
        });
      } else {
        open();
      }
    },
    lineChange(event) {
      var _a2;
      if (this.data.locked) {
        return;
      }
      const { index, line } = event.detail;
      if (resource === "dispatches") {
        const groups = this.data.groups.map(
          (group, current) => current === Number(event.currentTarget.dataset.group) ? {
            ...group,
            lines: group.lines.map((value, position) => position === index ? line : value)
          } : group
        );
        this.setData({ groups, confirming: false, error: "" });
      } else {
        const section = event.currentTarget.dataset.section === "vegetables" ? "vegetables" : "items";
        const lines = ((_a2 = this.data.document[section]) != null ? _a2 : []).map(
          (value, current) => current === index ? line : value
        );
        this.setData({
          document: { ...this.data.document, [section]: lines },
          confirming: false,
          error: ""
        });
      }
      save(this);
    },
    addLine(event) {
      var _a2;
      if (this.data.locked) {
        return;
      }
      if (resource === "dispatches") {
        const groups = this.data.groups.map(
          (group, current) => current === Number(event.currentTarget.dataset.group) ? { ...group, lines: [...group.lines, emptyLine(this.data.packaging)] } : group
        );
        this.setData({ groups });
      } else {
        const section = event.currentTarget.dataset.section === "vegetables" ? "vegetables" : "items";
        const options = section === "vegetables" || resource === "outbounds" ? this.data.vegetables : this.data.packaging;
        this.setData({
          document: {
            ...this.data.document,
            [section]: [...(_a2 = this.data.document[section]) != null ? _a2 : [], emptyLine(options)]
          }
        });
      }
      this.setData({ confirming: false });
      save(this);
    },
    removeLine(event) {
      var _a2;
      if (this.data.locked) {
        return;
      }
      if (resource === "dispatches") {
        const groups = this.data.groups.map(
          (group, current) => current === Number(event.currentTarget.dataset.group) ? {
            ...group,
            lines: group.lines.filter((_, position) => position !== event.detail.index)
          } : group
        );
        this.setData({ groups });
      } else {
        const section = event.currentTarget.dataset.section === "vegetables" ? "vegetables" : "items";
        this.setData({
          document: {
            ...this.data.document,
            [section]: ((_a2 = this.data.document[section]) != null ? _a2 : []).filter(
              (_, position) => position !== event.detail.index
            )
          }
        });
      }
      this.setData({ confirming: false });
      save(this);
    },
    addGrower() {
      if (!this.data.locked) {
        this.setData({
          groups: [
            ...this.data.groups,
            {
              key: Date.now(),
              growerId: 0,
              growerName: "\u8BF7\u9009\u62E9\u68DA\u6237",
              lines: [emptyLine(this.data.packaging)]
            }
          ],
          confirming: false
        });
        save(this);
      }
    },
    removeGrower(event) {
      if (!this.data.locked) {
        this.setData({
          groups: this.data.groups.filter(
            (_, index) => index !== Number(event.currentTarget.dataset.group)
          ),
          confirming: false
        });
        save(this);
      }
    },
    chooseMode(event) {
      if (this.data.locked) {
        return;
      }
      this.setData({
        document: {
          ...this.data.document,
          mode: String(event.currentTarget.dataset.mode),
          confirmFinal: false
        },
        confirming: false
      });
      save(this);
    },
    chooseLoss(event) {
      if (this.data.locked) {
        return;
      }
      const reason = String(event.currentTarget.dataset.reason);
      this.setData({
        lossChoice: reason,
        document: { ...this.data.document, lossReason: reason === "\u5176\u4ED6" ? "" : reason },
        confirming: false
      });
      save(this);
    },
    async preview() {
      var _a2;
      if (this.data.saving || this.data.locked) {
        return;
      }
      this.setData({ saving: true, error: "", lossRows: [], differenceRows: [] });
      try {
        const session = await requireSession();
        if (!session || session.userId !== this.data.ownerId || session.selectedRole !== role) {
          throw new Error("\u5F53\u524D\u8EAB\u4EFD\u5DF2\u53D8\u5316\uFF0C\u8BF7\u8FD4\u56DE\u9996\u9875\u91CD\u65B0\u9009\u62E9\u8EAB\u4EFD");
        }
        await refreshContext(this);
        const document = {
          ...inputFor(this),
          confirmFinal: resource === "recoveries" && this.data.document.mode === "FINAL"
        };
        const errors = validateDocument(document, resource, this.data.archives);
        if (resource === "dispatches") {
          for (const group of this.data.groups) {
            if (!this.data.growers.some((item) => item.id === group.growerId)) {
              errors.push("\u6BCF\u6237\u90FD\u8981\u9009\u62E9\u6709\u6548\u68DA\u6237");
            }
            if (!group.lines.length) {
              errors.push(`${group.growerName}\u81F3\u5C11\u586B\u5199\u4E00\u884C\u5305\u88C5`);
            }
          }
        }
        if (this.data.batch && this.data.batch.batch.status !== "OPEN") {
          errors.push("\u8FD9\u6237\u4EFB\u52A1\u5DF2\u7ECF\u7ED3\u675F\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9");
        }
        if ((resource === "work-records" || resource === "recoveries") && this.data.batch && !errors.length) {
          for (const line of document.items) {
            const balance = this.data.batch.packaging.find((item) => item.itemId === line.itemId);
            if (!balance) {
              errors.push("\u53EA\u80FD\u4F7F\u7528\u672C\u4EFB\u52A1\u5DF2\u7ECF\u6D3E\u53D1\u7684\u5305\u88C5");
            } else if (compareQuantities(lineTotal(document.items, line.itemId), balance.outstanding) > 0) {
              errors.push(`${balance.name}\u6570\u91CF\u8D85\u8FC7\u5F53\u524D\u5728\u5916\u91CF${balance.outstanding}${balance.unit}`);
            }
          }
        }
        if (resource === "recoveries" && this.data.batch && !errors.length) {
          const check = recoveryPreview(this.data.batch, document);
          this.setData({ lossRows: check.lossRows, differenceRows: check.differenceRows });
          errors.push(...check.errors);
        }
        if (resource === "outbounds" && !errors.length) {
          for (const line of document.items) {
            const balance = this.data.inventory.find((item) => item.id === line.itemId);
            if (compareQuantities(lineTotal(document.items, line.itemId), (_a2 = balance == null ? void 0 : balance.quantity) != null ? _a2 : "0") > 0) {
              errors.push("\u672C\u6B21\u51FA\u5E93\u8D85\u8FC7\u5F53\u524D\u5E93\u5B58\uFF0C\u8BF7\u6838\u5BF9\u6570\u91CF");
            }
          }
        }
        if (errors.length) {
          throw new Error([...new Set(errors)].join("\uFF1B"));
        }
        this.setData({
          document,
          summary: summary(this, document),
          confirming: true,
          notice: "\u8BF7\u6838\u5BF9\u65E5\u671F\u3001\u59D3\u540D\u3001\u54C1\u7C7B\u548C\u672C\u6B21\u6570\u91CF\u3002\u4E0B\u9762\u6309\u94AE\u624D\u4F1A\u6B63\u5F0F\u8BB0\u8D26\u3002"
        });
        wx.pageScrollTo({ selector: "#confirmation", duration: 250 });
      } catch (failure) {
        this.setData({ error: friendlyError(failure) });
      } finally {
        this.setData({ saving: false });
      }
    },
    backToEdit() {
      if (!this.data.locked) {
        this.setData({ confirming: false, notice: "" });
      }
    },
    async submit() {
      if (this.data.saving || this.data.locked && !this.data.pending || !this.data.confirming && !this.data.pending) {
        return;
      }
      this.setData({ saving: true, error: "" });
      try {
        const draft = getDraft(this.data.ownerId, resource, this.data.editingId || void 0);
        const result = await submitDocument(
          this.data.ownerId,
          resource,
          inputFor(this),
          draft == null ? void 0 : draft.ticket,
          this.data.editingId || void 0,
          this.data.version || void 0
        );
        if (result.result) {
          showSubmitted(resource, result.result);
        } else {
          this.setData({
            pending: true,
            locked: true,
            confirming: false,
            notice: "\u8FD8\u6CA1\u6709\u786E\u8BA4\u662F\u5426\u8BB0\u597D\u3002\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u70B9\u201C\u7EE7\u7EED\u786E\u8BA4\u539F\u63D0\u4EA4\u201D\uFF0C\u4E0D\u8981\u53E6\u5F00\u4E00\u7B14\u76F8\u540C\u8BB0\u5F55\u3002"
          });
        }
      } catch (failure) {
        const draft = getDraft(this.data.ownerId, resource, this.data.editingId || void 0);
        const known = failure instanceof ApiError && failure.status > 0 && failure.status < 500;
        if (known && draft) {
          rememberForm(this.data.ownerId, resource, draft.document, draft.editingId, draft.version);
        }
        this.setData({
          error: friendlyError(failure),
          pending: Boolean(draft == null ? void 0 : draft.ticket) && !known,
          locked: Boolean(draft == null ? void 0 : draft.ticket) && !known,
          confirming: false
        });
        if (this.data.editingId && known) {
          const latest = await api.request(
            "GET",
            `/api/${resource}/${this.data.editingId}`
          );
          this.setData({ version: latest.document.version });
        }
      } finally {
        this.setData({ saving: false });
      }
    },
    saveLater() {
      if (!this.data.pending) {
        save(this);
      }
      this.setData({
        notice: this.data.pending ? "\u539F\u63D0\u4EA4\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u8054\u7F51\u540E\u7EE7\u7EED\u786E\u8BA4\u3002" : "\u5DF2\u4FDD\u5B58\u5230\u672C\u673A\uFF0C\u5C1A\u672A\u8BB0\u8D26\u3002\u8054\u7F51\u540E\u53EF\u4EE5\u56DE\u6765\u7EE7\u7EED\u586B\u5199\u3002"
      });
    },
    retryLoad() {
      wx.redirectTo({
        url: `/pages/${resource === "work-records" ? "work" : resource === "dispatches" ? "dispatch" : resource === "recoveries" ? "recovery" : "outbound"}/index${this.data.editingId ? `?id=${this.data.editingId}` : this.data.document.batchId ? `?batchId=${this.data.document.batchId}` : ""}`
      });
    },
    discard() {
      if (this.data.pending) {
        return;
      }
      wx.showModal({
        title: "\u653E\u5F03\u672C\u673A\u8349\u7A3F\uFF1F",
        content: "\u4E0D\u4F1A\u5220\u9664\u5DF2\u7ECF\u4FDD\u5B58\u5230\u540E\u53F0\u7684\u8349\u7A3F\u3002",
        success: (choice) => {
          if (choice.confirm) {
            removeDraft(this.data.ownerId, resource, this.data.editingId || void 0);
            wx.disableAlertBeforeUnload();
            wx.navigateBack();
          }
        }
      });
    }
  };
}

// apps/miniprogram/src/pages/dispatch/index.ts
Page(createDocumentPage("dispatches", "DRIVER"));
/*! Bundled license information:

decimal.js/decimal.mjs:
  (*!
   *  decimal.js v10.6.0
   *  An arbitrary-precision Decimal type for JavaScript.
   *  https://github.com/MikeMcl/decimal.js
   *  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
   *  MIT Licence
   *)
*/
